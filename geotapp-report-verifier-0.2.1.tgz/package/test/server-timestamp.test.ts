import { describe, it, expect } from 'vitest';
import { checkServerTimestamp } from '../src/checkers/server-timestamp.js';
import { buildContext } from '../src/build-context.js';
import { buildValidArtifact } from './fixtures/factory.js';

function withServerReceivedAt(
  artifact: ReturnType<typeof buildValidArtifact>,
  serverReceivedAt: string,
  eventIndex = 0
) {
  const events = artifact.historyJson.events.map((e, i) =>
    i === eventIndex ? { ...e, serverReceivedAt } : e
  );
  return { ...artifact, historyJson: { ...artifact.historyJson, events } };
}

describe('checkServerTimestamp', () => {
  it('skips when no event has serverReceivedAt', () => {
    const artifact = buildValidArtifact({ eventsCount: 2 });
    const ctx = buildContext(artifact);
    const result = checkServerTimestamp(ctx);
    expect(result.skipped).toBe(true);
    expect(result.ok).toBe(true);
  });

  it('passes when device timestamp matches server timestamp (< 1h diff)', () => {
    const artifact = buildValidArtifact({ eventsCount: 2 });
    const event = artifact.historyJson.events[0];
    const serverTs = new Date(new Date(event.timestamp).getTime() + 5 * 60000).toISOString();
    const modified = withServerReceivedAt(artifact, serverTs, 0);
    const ctx = buildContext(modified);
    const result = checkServerTimestamp(ctx);
    expect(result.ok).toBe(true);
    expect(result.errors).toHaveLength(0);
    expect(result.skipped).toBeFalsy();
  });

  it('warns when difference is between 1h and 24h', () => {
    const artifact = buildValidArtifact({ eventsCount: 1 });
    const event = artifact.historyJson.events[0];
    const serverTs = new Date(new Date(event.timestamp).getTime() + 2 * 3600000).toISOString();
    const modified = withServerReceivedAt(artifact, serverTs, 0);
    const ctx = buildContext(modified);
    const result = checkServerTimestamp(ctx);
    expect(result.ok).toBe(true);
    expect(result.warnings.length).toBeGreaterThan(0);
    expect(result.errors).toHaveLength(0);
  });

  it('errors when difference exceeds 24h', () => {
    const artifact = buildValidArtifact({ eventsCount: 1 });
    const event = artifact.historyJson.events[0];
    const serverTs = new Date(new Date(event.timestamp).getTime() + 25 * 3600000).toISOString();
    const modified = withServerReceivedAt(artifact, serverTs, 0);
    const ctx = buildContext(modified);
    const result = checkServerTimestamp(ctx);
    expect(result.ok).toBe(false);
    expect(result.errors.some(e => e.includes('25'))).toBe(true);
  });
});
