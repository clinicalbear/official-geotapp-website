import type { VerificationContext, CheckResult } from '../types.js';

/**
 * Confronta il timestamp del dispositivo (event.timestamp) con il timestamp
 * server-autoritativo (event.serverReceivedAt) scritto da flowRecordProofServerTimestamp.
 *
 * > 24h di differenza → error (orologio dispositivo fuori sync o manomissione)
 * >  1h di differenza → warning
 * serverReceivedAt assente → skipped (report legacy o proof pre-v2.1)
 */
export function checkServerTimestamp(ctx: VerificationContext): CheckResult {
  const events = ctx.artifact.historyJson.events;
  const errors: string[] = [];
  const warnings: string[] = [];
  let checked = 0;
  let skippedCount = 0;

  for (const event of events) {
    const serverReceivedAt = event['serverReceivedAt'] as string | undefined;
    if (!serverReceivedAt) {
      skippedCount++;
      continue;
    }

    const deviceTs = new Date(event.timestamp).getTime();
    const serverTs = new Date(serverReceivedAt).getTime();
    if (isNaN(deviceTs) || isNaN(serverTs)) {
      skippedCount++;
      continue;
    }

    checked++;
    const diffHours = Math.abs(deviceTs - serverTs) / 3600000;

    if (diffHours > 24) {
      errors.push(
        `Evento ${event.eventId}: timestamp dispositivo (${event.timestamp}) ` +
        `differisce di ${diffHours.toFixed(1)}h dal timestamp server (${serverReceivedAt})`
      );
    } else if (diffHours > 1) {
      warnings.push(
        `Evento ${event.eventId}: timestamp dispositivo differisce di ` +
        `${diffHours.toFixed(1)}h dal timestamp server`
      );
    }
  }

  if (checked === 0) {
    return {
      ok: true,
      skipped: true,
      warnings: skippedCount > 0
        ? ['serverReceivedAt assente — verifica timestamp server saltata (report pre-v2.1)']
        : [],
      errors: [],
      details: { checked: 0, skipped: skippedCount },
    };
  }

  return {
    ok: errors.length === 0,
    warnings,
    errors,
    details: { checked, skipped: skippedCount },
  };
}
