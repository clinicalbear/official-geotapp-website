import type {
  ReportArtifact, VerificationContext,
  NormalizedEvent, NormalizedTimelineEvent, NormalizedPhoto,
  RawEvent,
} from './types.js';
import { sha256HexBytes } from './canonical.js';

/**
 * Normalize a timestamp to UTC ISO-8601 with millisecond precision and Z suffix.
 *
 * Dart's chain-hash code does:
 *   DateTime.fromMillisecondsSinceEpoch(ts.millisecondsSinceEpoch, isUtc: true)
 *       .toIso8601String()
 * which always produces e.g. "2026-03-20T16:44:28.080Z".
 *
 * The history.json may store the timestamp in local time without Z (e.g.
 * "2026-03-20T17:44:28.080" for CET).  We must convert to UTC+Z to match
 * the hash that Dart computed.
 */
function normalizeTimestamp(raw: string): string {
  if (!raw) return '';
  const d = new Date(raw);
  if (isNaN(d.getTime())) return raw; // unparseable → keep as-is
  return d.toISOString(); // always UTC with Z, ms precision
}

export function buildContext(artifact: ReportArtifact): VerificationContext {
  const { historyJson, reportMeta, historyJsonBytes } = artifact;

  // ── Sort events: timestamp → eventId → type → originalIndex ──────────────
  const events: NormalizedEvent[] = historyJson.events.map((e, i) => ({
    eventId: String(e.eventId ?? ''),
    timestamp: normalizeTimestamp(String(e.timestamp ?? '')),
    type: String(e.type ?? ''),
    user: String(e.user ?? ''),
    gps: {
      latitude: e.gps?.latitude ?? null,
      longitude: e.gps?.longitude ?? null,
    },
    description: String(e.description ?? ''),
    storedPreviousHash: String(e.previousEventHash ?? ''),
    storedEventHash: String(e.eventHash ?? ''),
    originalIndex: i,
  }));

  events.sort((a, b) => {
    if (a.timestamp !== b.timestamp) return a.timestamp < b.timestamp ? -1 : 1;
    if (a.eventId !== b.eventId) return a.eventId < b.eventId ? -1 : 1;
    if (a.type !== b.type) return a.type < b.type ? -1 : 1;
    return a.originalIndex - b.originalIndex;
  });

  // ── Timeline events (reduced payload) ────────────────────────────────────
  const timelineEvents: NormalizedTimelineEvent[] = events.map((e) => ({
    eventId: e.eventId,
    timestamp: e.timestamp,
    type: e.type,
    user: e.user,
    gps: e.gps,
    description: e.description,
  }));

  // ── Photos (extracted from proof events via photosMeta) ───────────────────
  // Photos are embedded in history.json events of type 'proof' as photosMeta.
  const photos: NormalizedPhoto[] = [];
  for (const rawEvent of historyJson.events) {
    if (rawEvent.type !== 'proof') continue;
    // Photos may be in `photosMeta` (v1) or `metadata.photoFiles` (v1.1+)
    const rawMeta = rawEvent as RawEvent & { photosMeta?: unknown[]; metadata?: Record<string, unknown> };
    const meta: unknown[] = Array.isArray(rawMeta.photosMeta)
      ? rawMeta.photosMeta
      : Array.isArray(rawMeta.metadata?.['photoFiles'])
        ? rawMeta.metadata!['photoFiles'] as unknown[]
        : [];
    if (!meta.length) continue;
    for (let i = 0; i < meta.length; i++) {
      const pm = meta[i] as Record<string, unknown>;
      photos.push({
        proofId: String(rawEvent.eventId ?? ''),
        proofTimestamp: normalizeTimestamp(String(rawEvent.timestamp ?? '')),
        photoOrder: i + 1,
        photoId: String(pm['photoId'] ?? ''),
        storagePath: String(pm['storagePath'] ?? ''),
        sourceUrl: String(pm['photoUrl'] ?? pm['sourceUrl'] ?? ''),
        fileSha256: String(pm['fileSha256'] ?? '').toLowerCase(),
        missingFile: pm['missingFile'] === true,
      });
    }
  }

  // Sort photos: proofTimestamp → proofId → photoOrder
  photos.sort((a, b) => {
    if (a.proofTimestamp !== b.proofTimestamp)
      return a.proofTimestamp < b.proofTimestamp ? -1 : 1;
    if (a.proofId !== b.proofId) return a.proofId < b.proofId ? -1 : 1;
    return a.photoOrder - b.photoOrder;
  });

  // ── Expected hashes — prefer report_meta over history.json ───────────────
  const timelineHashExpected =
    reportMeta?.timelineHash ?? historyJson.timelineHash ?? null;
  const photosBundleHashExpected =
    reportMeta?.photosBundleHash ?? historyJson.photosBundleHash ?? null;

  // ── Summary ───────────────────────────────────────────────────────────────
  const summary = {
    eventsCount: reportMeta?.eventsCount ?? historyJson.events.length,
    photosCount: reportMeta?.photosCount ?? photos.length,
    techniciansCount: reportMeta?.techniciansCount ?? 0,
  };

  return {
    artifact,
    events,
    timelineEvents,
    photos,
    historyHash: sha256HexBytes(historyJsonBytes),
    timelineHashExpected,
    photosBundleHashExpected,
    summary,
  };
}
