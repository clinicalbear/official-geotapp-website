import type { ReportArtifact, VerificationResult } from './types.js';
import { buildContext } from './build-context.js';
import { checkZipStructure, checkHistoryJson, checkReportMeta } from './checkers/zip-structure.js';
import { checkEventHashChain } from './checkers/event-hash-chain.js';
import { checkTimelineHash } from './checkers/timeline-hash.js';
import { checkPhotosBundleHash } from './checkers/photos-bundle-hash.js';
import { checkReportRootHash } from './checkers/report-root-hash.js';
import { checkPhotoFiles } from './checkers/photo-files.js';
import { checkArchiveSeal } from './checkers/archive-seal.js';
import { checkSignatureVerification } from './checkers/signature-verifier.js';
import { checkServerTimestamp } from './checkers/server-timestamp.js';
import { getPublicKeyForSeal } from './keys/index.js';
import { classifyStatus, classifyIntegrityLevel } from './classifier.js';

export function verifyArtifact(artifact: ReportArtifact): VerificationResult {
  // Structural checks (on raw artifact)
  const zipStructure = checkZipStructure(artifact);
  const historyJson = checkHistoryJson(artifact.historyJson);
  const reportMeta = checkReportMeta(artifact.reportMeta);

  // Build normalized context for hash checkers
  const ctx = buildContext(artifact);

  // Hash chain checks
  const eventHashChain = checkEventHashChain(ctx);
  const timelineHash = checkTimelineHash(ctx);
  const photosBundleHash = checkPhotosBundleHash(ctx);
  const reportRootHash = checkReportRootHash(ctx);

  // File integrity checks
  const photoFiles = checkPhotoFiles(ctx);
  const archiveSeal = checkArchiveSeal(ctx);

  // Signature verification (v2.0+ only — skipped for legacy reports without seal.json)
  const sealJson = artifact.sealJson ?? null;
  const pubKeyPem = getPublicKeyForSeal(sealJson?.keyId) ?? '';
  // If seal has a signature but we don't recognize the keyId, force invalid
  const rawSignatureCheck = checkSignatureVerification(sealJson, pubKeyPem);
  const signatureVerification =
    sealJson?.signature && !getPublicKeyForSeal(sealJson.keyId)
      ? {
          ok: false,
          warnings: [] as string[],
          errors: [`Chiave pubblica non trovata per keyId: ${sealJson.keyId}`],
          details: { signatureStatus: 'invalid' as const },
        }
      : rawSignatureCheck;

  const checks = {
    zipStructure,
    historyJson,
    reportMeta,
    eventHashChain,
    timelineHash,
    photosBundleHash,
    photoFiles,
    reportRootHash,
    archiveSeal,
    signatureVerification,
    serverTimestamp: checkServerTimestamp(ctx),
  };

  const status = classifyStatus(checks);
  const storedLevel = artifact.reportMeta?.integrityLevel;
  const integrityLevel = classifyIntegrityLevel(checks, storedLevel);

  const allWarnings = Object.values(checks).flatMap((c: any) => c.warnings ?? []);
  const allErrors = Object.values(checks).flatMap((c: any) => c.errors ?? []);

  const missingPhotos = (photoFiles.details?.['missing'] as number) ?? 0;
  const hashMismatches =
    (eventHashChain.details?.['failedCount'] as number ?? 0) +
    (photoFiles.errors?.length ?? 0);

  // Derive v2 fields from checks
  const sigStatusRaw = signatureVerification.details?.['signatureStatus'] as string | undefined;
  const signatureStatus: 'verified' | 'invalid' | 'absent' =
    sigStatusRaw === 'verified' ? 'verified'
    : sigStatusRaw === 'invalid' ? 'invalid'
    : 'absent';

  const sealStatus: 'sealed' | 'hash-only' | 'absent' =
    sealJson !== null
      ? (sealJson.signature ? 'sealed' : 'hash-only')
      : 'absent';

  return {
    status,
    integrityLevel,
    reportVersion: artifact.reportMeta?.reportVersion ?? artifact.historyJson.reportVersion ?? 'unknown',
    reportSealVersion: artifact.reportMeta?.reportSealVersion ?? 'unknown',
    signatureStatus,
    sealStatus,
    issuerDisplayName: sealJson?.issuer ?? null,
    companyIdentity: {
      companyId: sealJson?.companyId ?? (artifact.reportMeta?.companyId ?? null),
      companyName: (artifact.reportMeta as Record<string, unknown> | null)?.['companyName'] as string ?? null,
      reportId: sealJson?.reportId ?? null,
    },
    verificationMode: 'local' as const,
    checks,
    warnings: allWarnings,
    errors: allErrors,
    summary: {
      eventsCount: ctx.summary.eventsCount,
      photosCount: ctx.summary.photosCount,
      missingPhotos,
      hashMismatches,
    },
  };
}
