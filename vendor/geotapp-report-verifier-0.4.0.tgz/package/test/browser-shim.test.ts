/**
 * Il sostituto di `node:crypto` usato nella build da browser deve dare gli
 * stessi identici risultati di Node. Se un giorno divergessero, la pagina di
 * verifica direbbe "documento integro" su un documento alterato, o il
 * contrario: e' l'unico punto del verificatore dove un bug non si vede.
 *
 * Qui si confrontano le due implementazioni sulle stesse chiavi e sugli stessi
 * dati, compresa una firma ECDSA vera generata al momento.
 */
import { describe, it, expect } from 'vitest';
import {
  createHash as hashNode,
  createVerify as verifyNode,
  createSign,
  generateKeyPairSync,
} from 'node:crypto';
import {
  createHash as hashBrowser,
  createVerify as verifyBrowser,
} from '../src/browser/node-crypto-shim.js';

const CASI: Array<string | Uint8Array> = [
  '',
  'a',
  'GeoTapp',
  'accenti: à è ì ò ù, umlaut: ä ö ü ß, cirillico: проверка',
  JSON.stringify({ reportVersion: '1.1', eventi: [1, 2, 3] }),
  new Uint8Array([0, 1, 2, 253, 254, 255]),
  new Uint8Array(100_000).fill(7),
];

describe('shim di node:crypto per il browser', () => {
  it('calcola le stesse impronte SHA-256 di Node', () => {
    for (const caso of CASI) {
      const atteso = hashNode('sha256')
        .update(caso as never, typeof caso === 'string' ? 'utf8' : undefined)
        .digest('hex');
      const ottenuto = hashBrowser('sha256')
        .update(caso, typeof caso === 'string' ? 'utf8' : undefined)
        .digest('hex');
      expect(ottenuto).toBe(atteso);
    }
  });

  it('somma i pezzi come Node quando update viene chiamato piu volte', () => {
    const atteso = hashNode('sha256').update('uno').update('due').update('tre').digest('hex');
    const ottenuto = hashBrowser('sha256').update('uno').update('due').update('tre').digest('hex');
    expect(ottenuto).toBe(atteso);
  });

  /**
   * Trenta chiavi, non una.
   *
   * Con una sola chiave questo test passava una volta su due e sembrava
   * instabile. Non lo era: OpenSSL, e quindi Node, non normalizza il valore S
   * della firma, e circa meta' delle firme vere finisce nella meta' alta
   * dell'ordine della curva. @noble di suo le rifiuta. Con una chiave sola il
   * difetto si presenta a caso; con trenta si presenta sempre.
   */
  it('accetta le firme ECDSA P-256 di Node, anche quelle con S alta', () => {
    const messaggio = 'il sigillo di una commessa chiusa';
    for (let i = 0; i < 30; i++) {
      const { privateKey, publicKey } = generateKeyPairSync('ec', {
        namedCurve: 'prime256v1',
      });
      const pem = publicKey.export({ type: 'spki', format: 'pem' }).toString();

      const firma = createSign('SHA256').update(messaggio, 'utf8');
      firma.end();
      const firmaHex = firma.sign(privateKey, 'hex');

      const conNode = verifyNode('SHA256');
      conNode.update(messaggio, 'utf8');
      conNode.end();
      expect(conNode.verify(pem, firmaHex, 'hex')).toBe(true);

      const conShim = verifyBrowser('SHA256');
      conShim.update(messaggio, 'utf8');
      conShim.end();
      expect(conShim.verify(pem, firmaHex, 'hex'), `chiave numero ${i}`).toBe(true);
    }
  });

  it('rifiuta una firma valida applicata a un messaggio diverso', () => {
    const { privateKey, publicKey } = generateKeyPairSync('ec', {
      namedCurve: 'prime256v1',
    });
    const pem = publicKey.export({ type: 'spki', format: 'pem' }).toString();

    const firma = createSign('SHA256').update('originale', 'utf8');
    firma.end();
    const firmaHex = firma.sign(privateKey, 'hex');

    const conShim = verifyBrowser('SHA256');
    conShim.update('alterato', 'utf8');
    conShim.end();
    expect(conShim.verify(pem, firmaHex, 'hex')).toBe(false);
  });

  it('rifiuta una firma di un altra chiave', () => {
    const a = generateKeyPairSync('ec', { namedCurve: 'prime256v1' });
    const b = generateKeyPairSync('ec', { namedCurve: 'prime256v1' });
    const pemB = b.publicKey.export({ type: 'spki', format: 'pem' }).toString();

    const firma = createSign('SHA256').update('messaggio', 'utf8');
    firma.end();
    const firmaHex = firma.sign(a.privateKey, 'hex');

    const conShim = verifyBrowser('SHA256');
    conShim.update('messaggio', 'utf8');
    conShim.end();
    expect(conShim.verify(pemB, firmaHex, 'hex')).toBe(false);
  });

  it('non finge di sapere fare altri algoritmi', () => {
    expect(() => hashBrowser('sha512')).toThrow();
    expect(() => verifyBrowser('sha1')).toThrow();
  });
});
