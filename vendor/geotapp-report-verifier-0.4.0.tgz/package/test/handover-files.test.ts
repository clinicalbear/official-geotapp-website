// Consegne con firma dentro il rapportino (15/11/2026).
//
// Il pacchetto nuovo porta una voce `handover` nella catena e i file sotto
// `consegne/`. Quello che si difende qui:
//  - i pacchetti vecchi (senza consegne) continuano a validare, identici;
//  - il pacchetto nuovo valida, e il suo sigillo e' fatto come prima (nessun campo
//    nuovo nella firma: i verificatori gia' pubblicati restano buoni);
//  - un file di consegna alterato o tolto, o una dichiarazione ritoccata, e' invalido.
import { describe, it, expect } from 'vitest';
import { createSign } from 'node:crypto';
import { verifyArtifact } from '../src/verify.js';
import { canonicalJson, sha256Hex, sha256HexBytes } from '../src/canonical.js';
import { checkSignatureVerification } from '../src/checkers/signature-verifier.js';
import { computeHandoverBundleHash } from '../src/checkers/handover-files.js';
import { buildValidArtifact, TEST_KEY_PAIR } from './fixtures/factory.js';
import type { ReportArtifact, RawEvent, SealJson } from '../src/types.js';

const enc = (s: string) => new TextEncoder().encode(s);

/** Un pacchetto come lo produce il server: due righe di lavoro e una consegna con tre file. */
function pacchettoConConsegna(): ReportArtifact {
  const verbale = enc('%PDF-1.4 verbale firmato');
  const firma = enc('PNG-firma');
  const foto = enc('JPEG-foto-finale');
  const file = [
    { path: 'consegne/h1/verbale.pdf', sha256: sha256HexBytes(verbale) },
    { path: 'consegne/h1/firma.png', sha256: sha256HexBytes(firma) },
    { path: 'consegne/h1/foto_1.jpg', sha256: sha256HexBytes(foto) },
  ];
  const impronta = computeHandoverBundleHash(file);

  const grezzi = [
    { eventId: 'evt_1', ts: '2026-11-15T08:00:00.000Z', type: 'sessionStart', user: 'Mario', description: 'Ingresso di Mario', metadata: {} },
    {
      eventId: 'evt_2', ts: '2026-11-15T10:30:00.000Z', type: 'handover', user: 'Mario',
      description: `Consegna firmata da Anna Bianchi [consegna-sha256:${impronta}]`,
      metadata: { handoverId: 'h1', firmatoDa: 'Anna Bianchi', handoverFiles: file, handoverBundleHash: impronta },
    },
    { eventId: 'evt_3', ts: '2026-11-15T11:00:00.000Z', type: 'sessionEnd', user: 'Mario', description: 'Uscita di Mario', metadata: {} },
  ];
  const events: RawEvent[] = [];
  let prev = '';
  for (const g of grezzi) {
    const gps = { latitude: null, longitude: null };
    const eventHash = sha256Hex(canonicalJson({
      eventId: g.eventId, timestamp: g.ts, type: g.type, user: g.user, gps, description: g.description, previousEventHash: prev,
    }));
    events.push({
      eventId: g.eventId, timestamp: g.ts, type: g.type, user: g.user, gps, description: g.description,
      previousEventHash: prev, eventHash, metadata: g.metadata,
    } as RawEvent);
    prev = eventHash;
  }
  // timelineHash come lo calcola il verificatore: stessa catena sui campi ridotti.
  const timelineHash = prev;
  const photosBundleHash = sha256Hex(canonicalJson([]));
  const summary = { eventsCount: 3, photosCount: 0, techniciansCount: 1 };
  const historyJson = { reportVersion: '1.1', generatedAt: '2026-11-15T12:00:00.000Z', timelineHash, photosBundleHash, summary, events };
  const historyJsonBytes = enc(JSON.stringify(historyJson));
  const historyHash = sha256Hex(new TextDecoder().decode(historyJsonBytes));
  const reportRootHash = sha256Hex(canonicalJson({
    historyHash, summary, eventsCount: 3, photosCount: 0, techniciansCount: 1, timelineHash, photosBundleHash,
    archiveProjectRootHash: null, reportVersion: '1.1', reportSealVersion: '1.0',
  }));
  return {
    historyJson,
    reportMeta: {
      reportVersion: '1.1', reportSealVersion: '1.0', eventsCount: 3, photosCount: 0, techniciansCount: 1,
      hash: historyHash, timelineHash, photosBundleHash, archiveProjectRootHash: null, reportRootHash, integrityLevel: 'partial',
      // Fuori dal root hash, come `photosOmitted`.
      handover: { count: 1, filesCount: 3, filesOmitted: 0, notIncluded: 0 },
    } as ReportArtifact['reportMeta'],
    sealJson: null,
    historyJsonBytes,
    photoFiles: new Map(),
    handoverFiles: new Map([
      ['consegne/h1/verbale.pdf', verbale],
      ['consegne/h1/firma.png', firma],
      ['consegne/h1/foto_1.jpg', foto],
    ]),
  };
}

describe('consegne firmate nel pacchetto', () => {
  it('pacchetto vecchio, senza consegne: valido e il controllo si salta', () => {
    const r = verifyArtifact(buildValidArtifact({ eventsCount: 3 }));
    expect(r.status).toBe('valid');
    expect(r.checks.handoverFiles?.skipped).toBe(true);
  });

  it('pacchetto nuovo con consegna: valido, tre file verificati', () => {
    const r = verifyArtifact(pacchettoConConsegna());
    expect(r.errors).toEqual([]);
    expect(r.status).toBe('valid');
    expect(r.checks.eventHashChain.ok).toBe(true);
    expect(r.checks.handoverFiles?.ok).toBe(true);
    expect(r.checks.handoverFiles?.details?.['filesVerified']).toBe(3);
  });

  it('il sigillo resta quello di prima: la firma copre i soli campi gia\' noti', () => {
    const a = pacchettoConConsegna();
    const m = a.reportMeta!;
    const payload = {
      projectId: 'evt-1', companyId: 'c1', sealedAt: '2026-11-15T12:00:00.000Z',
      eventsCount: m.eventsCount, photosCount: 0, techniciansCount: 1,
      timelineHash: m.timelineHash, photosBundleHash: m.photosBundleHash, sealVersion: '2.1',
      pdfSha256: 'ab'.repeat(32),
    };
    const sign = createSign('SHA256');
    sign.update(canonicalJson(payload), 'utf8');
    const seal: SealJson = {
      version: '2.0', sealVersion: '2.1', algorithm: 'ES256', canonicalizationMethod: 'canonical-json-v1',
      signedAt: payload.sealedAt, issuer: 'GeoTapp Flow', issuerType: 'platform', keyId: 'k', signedRootHash: '',
      signature: sign.sign(TEST_KEY_PAIR.privateKey, 'hex'), companyId: 'c1', reportId: 'rpt', projectId: 'evt-1',
      eventsCount: m.eventsCount, photosCount: 0, techniciansCount: 1, timelineHash: m.timelineHash,
      photosBundleHash: m.photosBundleHash, pdfSha256: payload.pdfSha256,
    };
    expect(checkSignatureVerification(seal, TEST_KEY_PAIR.publicKey).ok).toBe(true);
  });

  it('un file della consegna alterato: invalido', () => {
    const a = pacchettoConConsegna();
    a.handoverFiles!.set('consegne/h1/verbale.pdf', enc('%PDF-1.4 verbale RITOCCATO'));
    const r = verifyArtifact(a);
    expect(r.status).toBe('invalid');
    expect(r.checks.handoverFiles?.ok).toBe(false);
    expect(r.errors.some((e) => e.includes('impronta diversa'))).toBe(true);
  });

  it('un file della consegna tolto dal pacchetto: invalido', () => {
    const a = pacchettoConConsegna();
    a.handoverFiles!.delete('consegne/h1/firma.png');
    const r = verifyArtifact(a);
    expect(r.status).toBe('invalid');
    expect(r.errors.some((e) => e.includes('file mancante'))).toBe(true);
  });

  it('file e dichiarazione ritoccati insieme: invalido, l\'impronta firmata nella catena non torna', () => {
    const a = pacchettoConConsegna();
    const falso = enc('%PDF-1.4 verbale falso');
    a.handoverFiles!.set('consegne/h1/verbale.pdf', falso);
    const ev = a.historyJson.events[1] as RawEvent & { metadata: { handoverFiles: Array<{ path: string; sha256: string }> } };
    ev.metadata.handoverFiles[0].sha256 = sha256HexBytes(falso);
    const r = verifyArtifact(a);
    expect(r.status).toBe('invalid');
    expect(r.errors.some((e) => e.includes('non coincide con l\'impronta firmata'))).toBe(true);
  });

  it('impronta ritoccata anche nella descrizione: invalido, si rompe la catena', () => {
    const a = pacchettoConConsegna();
    const ev = a.historyJson.events[1];
    ev.description = ev.description.replace(/[0-9a-f]{64}/, 'f'.repeat(64));
    const r = verifyArtifact(a);
    expect(r.status).toBe('invalid');
    expect(r.checks.eventHashChain.ok).toBe(false);
  });

  it('un file in piu\' nel pacchetto non dichiarato: avviso, non invalido', () => {
    const a = pacchettoConConsegna();
    a.handoverFiles!.set('consegne/h1/extra.bin', enc('x'));
    const r = verifyArtifact(a);
    expect(r.checks.handoverFiles?.ok).toBe(true);
    expect(r.checks.handoverFiles?.warnings.some((w) => w.includes('extra.bin'))).toBe(true);
  });

  it('vettore fisso: la stessa regola del server', () => {
    // Lo stesso vettore e' nel test di firebase-functions-clean (consegneNelRapportino).
    expect(computeHandoverBundleHash([
      { path: 'consegne/h1/verbale.pdf', sha256: 'aa'.repeat(32) },
      { path: 'consegne/h1/firma.png', sha256: 'BB'.repeat(32) },
    ])).toBe(sha256Hex(JSON.stringify([
      { path: 'consegne/h1/firma.png', sha256: 'bb'.repeat(32) },
      { path: 'consegne/h1/verbale.pdf', sha256: 'aa'.repeat(32) },
    ])));
  });
});
