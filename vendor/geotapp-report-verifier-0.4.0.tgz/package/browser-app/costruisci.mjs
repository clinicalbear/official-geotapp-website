/**
 * Cuce il verificatore dentro un unico file HTML.
 *
 * Il risultato si apre con doppio clic e funziona da `file://`: niente
 * installazione, niente account, niente internet, niente permessi di
 * amministratore. Sono le quattro cose che, in un ente pubblico, impediscono a
 * una persona di controllare da se' un documento. Un .exe le fallirebbe tutte
 * e quattro, e per giunta non firmato verrebbe bloccato da SmartScreen.
 *
 * Il programma di verifica non viene ricopiato a mano: si prende il bundle
 * costruito da scripts/build-offline.sh, cosi' la versione nella pagina e
 * quella da riga di comando restano per forza la stessa cosa.
 */
import { readFileSync, writeFileSync, statSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const qui = dirname(fileURLToPath(import.meta.url));
const radice = join(qui, '..');

const BUNDLE = join(radice, 'offline', 'geotapp-verifier.browser.js');
const MODELLO = join(qui, 'modello.html');
const USCITA = join(radice, 'offline', 'verificatore-geotapp.html');

const bundle = readFileSync(BUNDLE, 'utf8');
const modello = readFileSync(MODELLO, 'utf8');

if (!modello.includes('/*__VERIFICATORE__*/')) {
  throw new Error('nel modello manca il segnaposto /*__VERIFICATORE__*/');
}
if (!bundle.includes('GeoTappVerifier')) {
  throw new Error('il bundle non espone GeoTappVerifier: ricostruirlo in formato iife');
}

// `</script>` dentro una stringa del bundle chiuderebbe il tag e romperebbe la
// pagina in silenzio. Si spezza in modo che il browser non lo riconosca.
const sicuro = bundle.replace(/<\/script>/gi, '<\\/script>');

const pagina = modello.replace('/*__VERIFICATORE__*/', () => sicuro);

// Nessuna risorsa esterna: se ne restasse una, il file non funzionerebbe
// offline e la promessa cadrebbe proprio dove conta.
const esterne = pagina.match(/(?:src|href)\s*=\s*["']https?:\/\/[^"']+/gi);
if (esterne) {
  throw new Error('la pagina punta a risorse esterne:\n' + esterne.join('\n'));
}
if (/\bfetch\s*\(|XMLHttpRequest|navigator\.sendBeacon/.test(pagina)) {
  throw new Error('la pagina contiene una primitiva di rete');
}

writeFileSync(USCITA, pagina);

const dim = statSync(USCITA).size;
const impronta = createHash('sha256').update(readFileSync(USCITA)).digest('hex');
console.log('scritto  :', USCITA);
console.log('dimensione:', (dim / 1024).toFixed(0), 'KB');
console.log('sha256   :', impronta);
