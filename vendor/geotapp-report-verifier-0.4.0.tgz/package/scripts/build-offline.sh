#!/usr/bin/env bash
# Costruisce il verificatore in un file solo, da consegnare al committente.
#
# Perche' un bundle e non il pacchetto npm: `npm install` di un tgz va a
# scaricare commander e jszip dalla rete, e la promessa che facciamo al
# cliente e' che il controllo si fa SENZA internet e SENZA account. Un file
# unico con le dipendenze dentro e' l'unica forma che regge quella frase.
#
# La chiave pubblica del sigillo e' gia' una stringa dentro src/keys/index.ts,
# quindi entra nel bundle da sola: non serve portarsi dietro il .pem.

set -euo pipefail
cd "$(dirname "$0")/.."

VERSIONE=$(node -p "require('./package.json').version")
USCITA="offline"
BUNDLE="$USCITA/geotapp-report-verify.cjs"
PACCO="geotapp-report-verifier-offline-$VERSIONE.zip"

echo "== test =="
npx vitest run --reporter=basic

echo "== bundle =="
npx esbuild src/cli.ts \
  --bundle --platform=node --target=node18 --format=cjs \
  --legal-comments=none \
  --banner:js='#!/usr/bin/env node' \
  --outfile="$BUNDLE"

echo "== nessuna chiamata di rete nel bundle =="
if grep -qE "require\((['\"])https?\1\)|\bfetch\(" "$BUNDLE"; then
  echo "TROVATA una primitiva di rete nel bundle: mi fermo" >&2
  exit 1
fi

echo "== prova a rete staccata =="
# unshare -rn crea un namespace di rete vuoto: se il programma avesse
# bisogno della rete, qui fallirebbe.
if [ -n "${VERIFICA_SU:-}" ]; then
  unshare -rn -- node "$BUNDLE" "$VERIFICA_SU"
else
  echo "   (salta: passare VERIFICA_SU=/percorso/report.zip per la prova)"
fi

echo "== bundle per il browser =="
# La pagina di verifica esegue lo stesso verificatore dentro il browser di chi
# legge, cosi' il pacchetto non ci viene inviato. `node:crypto` e `node:fs`
# non esistono li' e vengono sostituiti: lo shim ha i suoi test in
# test/browser-shim.test.ts, che girano qui sopra.
npx esbuild src/browser/entry.ts \
  --bundle --format=iife --global-name=GeoTappVerifier \
  --platform=browser --target=es2020 --legal-comments=none \
  --alias:node:crypto=./src/browser/node-crypto-shim.ts \
  --alias:node:fs/promises=./src/browser/node-fs-stub.ts \
  --outfile="$USCITA/geotapp-verifier.browser.js"

echo "== verificatore in un file solo, per chi non usa il terminale =="
# Il terminale e' un muro: chi deve controllare un documento in un ente
# pubblico spesso non puo' nemmeno installare software. Questo si apre con
# doppio clic e funziona da file://, senza rete.
node browser-app/costruisci.mjs

echo "== impronte =="
# SHA256SUMS.txt elenca SOLO i file che finiscono nel pacchetto consegnato.
# Elencarne uno in piu' fa fallire `sha256sum -c` a chi segue le istruzioni,
# e a chi deve valutarci un controllo che dice FAILED sembra manomissione.
( cd "$USCITA" && sha256sum verificatore-geotapp.html geotapp-report-verify.cjs > SHA256SUMS.txt )
cat "$USCITA/SHA256SUMS.txt"
echo "   (bundle del sito, non nel pacchetto:)"
sha256sum "$USCITA/geotapp-verifier.browser.js"

echo "== pacchetto da allegare =="
rm -f "$PACCO"
( cd "$USCITA" && zip -q -r "../$PACCO" verificatore-geotapp.html geotapp-report-verify.cjs LIESMICH.txt SHA256SUMS.txt )
ls -la "$PACCO"

# ── il passo che mancava, e che nessuno faceva ────────────────────────────
# Il verificatore che la gente scarica NON e' questo: e' la copia dentro
# geotapp-site/public/. Fino al 16/09/2026 il file servito era del 23 agosto,
# perche' la copia era un passo a mano e si dimenticava. Adesso la fa lo
# script: ricostruire senza pubblicare era un lavoro che non arrivava a
# nessuno.
SITO="$(cd "$(dirname "$0")/../.." && pwd)/geotapp-site/public"
if [ -d "$SITO/downloads" ]; then
  cp "$USCITA/verificatore-geotapp.html" "$SITO/downloads/verificatore-geotapp.html"
  cp "$USCITA/geotapp-report-verify.cjs" "$SITO/downloads/geotapp-report-verify.cjs"
  cp "$PACCO" "$SITO/geotapp-report-verifier-offline.zip"
  echo "== copiato nel sito =="
  ls -la "$SITO/downloads/verificatore-geotapp.html" "$SITO/geotapp-report-verifier-offline.zip"
else
  echo "!! geotapp-site/public non trovato: la copia nel sito NON e' stata fatta" >&2
fi

echo "fatto: $PACCO"
