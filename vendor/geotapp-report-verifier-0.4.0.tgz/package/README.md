# @geotapp/report-verifier

Offline integrity verifier for exported GeoTapp operational reports.

Answers: *"Is this GeoTapp report internally consistent and does it match the integrity metadata it claims to contain?"*

Works entirely offline from the report ZIP artifact — no API calls, no Firebase, no network required.

## Install

```bash
npm install @geotapp/report-verifier
```

## CLI

```bash
npx geotapp-report-verify path/to/report.zip
npx geotapp-report-verify path/to/report.zip --json
npx geotapp-report-verify path/to/extracted-folder/ --verbose
```

Exit codes: `0` = valid/degraded, `1` = invalid, `2` = I/O or parse error.

## Programmatic API

```typescript
import { verifyZipFile, verifyFolder, verifyArtifact } from '@geotapp/report-verifier';

const result = await verifyZipFile('./report.zip');
console.log(result.status);          // 'valid' | 'degraded' | 'invalid'
console.log(result.integrityLevel);  // 'full' | 'partial' | 'legacy' | 'invalid'
```

## Integrity Levels

| Level | Meaning |
|---|---|
| `full` | Archive seal present + all hashes valid + strong SHA-256 for all photos |
| `partial` | All hashes valid but archive seal absent or legacy photo fallbacks used |
| `legacy` | Report lacks modern integrity fields; structure is readable but not fully verifiable |
| `invalid` | Hash chain broken, root hash mismatch, or unrecoverable inconsistency |

## Verification Model

The verifier checks, in order:

1. **ZIP structure** — required files present
2. **history.json** — parseable, events array valid
3. **report_meta.json** — parseable, version fields present
4. **Event hash chain** — each event's SHA-256 matches its stored `eventHash`; `previousEventHash` links correctly
5. **Timeline hash** — recomputed from normalized event sequence matches stored `timelineHash`
6. **Photos bundle hash** — recomputed from photo metadata (with legacy fallback) matches stored `photosBundleHash`
7. **Report root hash** — SHA-256 of combined report payload matches stored `reportRootHash`
8. **Photo files** — physical bytes in ZIP match `fileSha256` in metadata (when present)
9. **Archive seal** — optional; if present, seal hashes must match report metadata

## Important

**`report.html` is informational only.** It is not part of the canonical verification inputs and is never hashed. The canonical verification inputs are `data/history.json` and `metadata/report_meta.json`.

## Consegna al committente: il file unico offline

La promessa che facciamo nei documenti (Fragekatalog BVG, Q10 e Q17) e' che il
committente possa controllare da se' il pacchetto ricevuto, **senza account,
senza collegamento a internet e senza passare dai nostri sistemi**.

Il pacchetto npm non regge quella frase: `npm install` di un tgz va comunque a
scaricare `commander` e `jszip` dalla rete. Quello che si consegna e' un **file
unico** con le dipendenze e la chiave pubblica gia' dentro:

```
npm run build:offline
# oppure, con la prova su un report vero:
VERIFICA_SU=/percorso/report.zip npm run build:offline
```

Produce `geotapp-report-verifier-offline-<versione>.zip` (circa 90 KB) con:

| File | Cosa e' |
|---|---|
| `verificatore-geotapp.html` | **il modo semplice**: si apre con doppio clic, ci si trascina dentro lo ZIP. Undici lingue, nessuna installazione, nessun permesso di amministratore |
| `geotapp-report-verify.cjs` | lo stesso verificatore da riga di comando, per l'uso automatico |
| `LIESMICH.txt` | istruzioni in tedesco, esiti, cosa viene controllato |
| `SHA256SUMS.txt` | impronta del file, per controllare di aver ricevuto il nostro |

Uso da parte del committente: `node geotapp-report-verify.cjs bericht.zip`.
Serve solo Node 18 o superiore.

Lo script di build si ferma da solo se nel bundle compare una primitiva di rete,
e se gli si passa `VERIFICA_SU` esegue la verifica dentro un namespace di rete
vuoto (`unshare -rn`): se il programma avesse bisogno di internet, li' fallirebbe.

**Attenzione a non confondere due cose.** La pagina `geotapp.com/verify-report`
esegue la verifica **sui nostri server** e risponde `verificationMode: "online"`.
Va bene come comodita', ma non e' la verifica indipendente: quella e' il file
qui sopra.


## Perche' un file HTML e non un programma da installare

La domanda viene sempre: "un'app con l'interfaccia, no?". La risposta e' no, e
non per pigrizia.

Chi deve controllare un documento in un ente pubblico **non ha i permessi per
installare software** sul computer di lavoro. Un eseguibile non firmato
arrivato per email e' esattamente cio' che gli insegnano a cestinare, e senza
firma SmartScreen lo blocca comunque; il certificato costa e va rinnovato.
Poi sarebbero tre piattaforme da costruire e mantenere.

`verificatore-geotapp.html` non fallisce nessuno di questi punti: e' un file
di testo, si apre nel browser che la persona ha gia', funziona da `file://`
senza rete, e si puo' leggere per intero prima di aprirlo.

Lo script di build si rifiuta di produrlo se dentro resta un riferimento
esterno (`src`/`href` verso http) o una primitiva di rete.

## La trappola della firma ECDSA

`@noble` di suo **rifiuta le firme con S nella meta' alta** dell'ordine della
curva, perche' in un sistema a firma canonica sono un vettore di
malleabilita'. OpenSSL, e quindi Node, non normalizza S: circa **meta' delle
firme vere** finisce li' dentro (misurato: 23 su 40).

Con l'impostazione predefinita il verificatore da browser avrebbe scritto
"documento non integro" su un rapporto genuino su due. Per questo lo shim
passa `lowS: false`, e per questo il test prova **trenta chiavi** e non una:
con una sola il difetto si presentava a caso e sembrava un test instabile.
