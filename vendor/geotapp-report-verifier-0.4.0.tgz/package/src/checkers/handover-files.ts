import type { VerificationContext, CheckResult } from '../types.js';
import { canonicalJson, sha256Hex, sha256HexBytes } from '../canonical.js';

/**
 * Consegne con firma dentro il rapportino (15/11/2026).
 *
 * Ogni consegna e' una voce `handover` della catena. I suoi file stanno nel
 * pacchetto sotto `consegne/<id>/` e la loro impronta e' scritta in due posti:
 *   - `metadata.handoverFiles`, l'elenco (percorso, sha256) letto qui;
 *   - la descrizione della voce, in coda, come `[consegna-sha256:<hash>]`.
 * La descrizione e' coperta dall'impronta di ogni evento e quindi dalla firma del
 * sigillo: per ritoccare un file bisognerebbe rifare la catena e la firma.
 *
 * Il sigillo NON cambia: i verificatori gia' pubblicati continuano a validare
 * tutto il resto del pacchetto, e non sanno controllare questi file. Questo
 * controllo e' in piu', e nei pacchetti senza consegne si salta da solo.
 *
 * La regola dell'impronta deve restare identica a `impronteConsegna` in
 * firebase-functions-clean/src/lib/consegneNelRapportino.ts.
 */

const MARCATORE = /\[consegna-sha256:([0-9a-f]{64})\]/;
const PREFISSO = 'consegne/';

interface FileDichiarato {
  path: string;
  sha256: string;
}

/** sha256 della lista (percorso, impronta) in ordine di percorso, in JSON canonico. */
export function computeHandoverBundleHash(files: FileDichiarato[]): string {
  const ordinati = [...files]
    .sort((a, b) => (a.path < b.path ? -1 : a.path > b.path ? 1 : 0))
    .map((f) => ({ path: f.path, sha256: f.sha256.toLowerCase() }));
  // canonicalJson ordina le chiavi: lo stesso risultato di JSON.stringify con path prima di sha256.
  return sha256Hex(canonicalJson(ordinati));
}

export function checkHandoverFiles(ctx: VerificationContext): CheckResult {
  const eventi = ctx.artifact.historyJson.events.filter((e) => e.type === 'handover');
  const presenti = ctx.artifact.handoverFiles ?? new Map<string, Uint8Array>();

  // Pacchetto senza consegne (tutti quelli emessi finora): niente da controllare.
  if (eventi.length === 0 && presenti.size === 0) {
    return { ok: true, skipped: true, warnings: [], errors: [] };
  }

  const errors: string[] = [];
  const warnings: string[] = [];
  const dichiarati = new Set<string>();
  let verificati = 0;

  for (const e of eventi) {
    const id = String((e.metadata as Record<string, unknown> | undefined)?.['handoverId'] ?? e.eventId);
    const grezzo = (e.metadata as Record<string, unknown> | undefined)?.['handoverFiles'];
    const file: FileDichiarato[] = Array.isArray(grezzo)
      ? (grezzo as Array<Record<string, unknown>>).map((f) => ({
          path: String(f['path'] ?? ''),
          sha256: String(f['sha256'] ?? '').toLowerCase(),
        }))
      : [];
    if (file.length === 0) {
      errors.push(`Consegna ${id}: elenco dei file assente nella voce della catena`);
      continue;
    }

    // L'impronta firmata nella catena deve essere quella dei file dichiarati.
    const marcatore = MARCATORE.exec(String(e.description ?? ''));
    if (!marcatore) {
      errors.push(`Consegna ${id}: impronta dei file assente nella descrizione firmata`);
    } else if (marcatore[1] !== computeHandoverBundleHash(file)) {
      errors.push(`Consegna ${id}: l'elenco dei file non coincide con l'impronta firmata nella catena`);
    }

    // E i byte nel pacchetto devono essere quelli dichiarati.
    for (const f of file) {
      dichiarati.add(f.path);
      if (!f.path.startsWith(PREFISSO) || f.path.includes('..')) {
        errors.push(`Consegna ${id}: percorso non ammesso ${f.path}`);
        continue;
      }
      const byte = presenti.get(f.path);
      if (!byte) {
        errors.push(`Consegna ${id}: file mancante nel pacchetto (${f.path})`);
        continue;
      }
      const calcolato = sha256HexBytes(byte);
      if (calcolato !== f.sha256) {
        errors.push(
          `Consegna ${id}: impronta diversa per ${f.path} (calcolata ${calcolato.slice(0, 8)}…, dichiarata ${f.sha256.slice(0, 8)}…)`,
        );
      } else {
        verificati++;
      }
    }
  }

  // File nel pacchetto che nessuna voce della catena dichiara: non fanno parte del sigillo.
  for (const nome of presenti.keys()) {
    if (!dichiarati.has(nome)) {
      warnings.push(`File ${nome} nel pacchetto ma non dichiarato da nessuna consegna`);
    }
  }

  return {
    ok: errors.length === 0,
    errors,
    warnings,
    details: { handovers: eventi.length, filesVerified: verificati },
  };
}
