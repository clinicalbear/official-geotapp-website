/**
 * Punto di ingresso della build da browser.
 *
 * Non passa da `src/index.ts` perche' quello esporta anche il lettore da
 * cartella e `verifyZipFile`, che usano il filesystem: nel browser non
 * esistono e trascinerebbero dentro roba che non serve.
 */

import { verifyArtifact } from '../verify.js';
import { readReportFromZipBuffer } from '../reader/zip-reader.js';
import type { VerificationResult } from '../types.js';

export { verifyArtifact, readReportFromZipBuffer };

/** Verifica un pacchetto .zip gia' letto in memoria. Non contatta nulla. */
export async function verificaPacchetto(
  byte: Uint8Array,
): Promise<VerificationResult & { verificationMode: 'offline' }> {
  const artefatto = await readReportFromZipBuffer(byte);
  return { ...verifyArtifact(artefatto), verificationMode: 'offline' as const };
}
