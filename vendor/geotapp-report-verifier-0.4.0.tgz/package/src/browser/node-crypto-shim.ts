/**
 * Sostituto di `node:crypto` per la build da browser.
 *
 * Serve a una cosa sola: far girare **lo stesso identico codice di verifica**
 * dentro il browser di chi ha ricevuto il report, senza mandarci il pacchetto.
 * Il nucleo (canonical.ts, i checker, il classificatore) non viene toccato:
 * qui si rimpiazzano solo le due primitive che in Node arrivano da `crypto`.
 *
 * Perche' non WebCrypto: WebCrypto e' asincrono, e il nucleo calcola le
 * impronte in modo sincrono dentro cicli. Riscriverlo in async vorrebbe dire
 * riscrivere la parte che ha 107 test verdi, cioe' rischiare proprio dove non
 * si puo' rischiare. @noble e' sincrono e fa la stessa matematica.
 */

import { sha256 } from '@noble/hashes/sha2.js';
import { p256 } from '@noble/curves/nist.js';
import { bytesToHex, concatBytes, utf8ToBytes } from '@noble/hashes/utils.js';

type Ingresso = string | Uint8Array | ArrayBuffer;

function aByte(dato: Ingresso): Uint8Array {
  if (typeof dato === 'string') return utf8ToBytes(dato);
  if (dato instanceof Uint8Array) return dato;
  return new Uint8Array(dato);
}

class Hash {
  private pezzi: Uint8Array[] = [];

  update(dato: Ingresso, _codifica?: string): Hash {
    this.pezzi.push(aByte(dato));
    return this;
  }

  digest(formato?: 'hex'): string | Uint8Array {
    const somma = sha256(concatBytes(...this.pezzi));
    return formato === 'hex' ? bytesToHex(somma) : somma;
  }
}

export function createHash(algoritmo: string): Hash {
  if (algoritmo.toLowerCase().replace('-', '') !== 'sha256') {
    throw new Error(`node-crypto-shim: algoritmo non previsto: ${algoritmo}`);
  }
  return new Hash();
}

/**
 * Estrae il punto della curva dalla chiave pubblica in formato PEM.
 *
 * Il PEM contiene un SubjectPublicKeyInfo in DER. Per P-256 il punto non
 * compresso sta in fondo: 65 byte che iniziano con 0x04. Si prende quello,
 * invece di scrivere un parser ASN.1 che qui non servirebbe a nessuno.
 */
function puntoDaPem(pem: string): Uint8Array {
  const base64 = pem
    .replace(/-----BEGIN [^-]+-----/, '')
    .replace(/-----END [^-]+-----/, '')
    .replace(/\s+/g, '');
  const binario = atob(base64);
  const der = new Uint8Array(binario.length);
  for (let i = 0; i < binario.length; i++) der[i] = binario.charCodeAt(i);

  const punto = der.slice(der.length - 65);
  if (punto[0] !== 0x04) {
    throw new Error('node-crypto-shim: chiave pubblica non riconosciuta');
  }
  return punto;
}

function daHex(hex: string): Uint8Array {
  const pulito = hex.trim();
  const out = new Uint8Array(pulito.length / 2);
  for (let i = 0; i < out.length; i++) {
    out[i] = parseInt(pulito.slice(i * 2, i * 2 + 2), 16);
  }
  return out;
}

class Verify {
  private pezzi: Uint8Array[] = [];

  update(dato: Ingresso, _codifica?: string): Verify {
    this.pezzi.push(aByte(dato));
    return this;
  }

  end(): void {
    /* in Node chiude lo stream, qui non c'e' nulla da chiudere */
  }

  verify(pem: string, firma: string | Uint8Array, formato?: string): boolean {
    const impronta = sha256(concatBytes(...this.pezzi));
    const byteFirma =
      typeof firma === 'string'
        ? formato === 'hex'
          ? daHex(firma)
          : aByte(firma)
        : firma;
    try {
      // Due dettagli che, sbagliati, fanno dichiarare falso un documento vero.
      //
      // `format: 'der'`: Node produce firme ECDSA in DER. Si dichiara, non si
      // indovina.
      //
      // `lowS: false`: @noble di suo rifiuta le firme con S nella meta' alta
      // dell'ordine della curva, perche' in un sistema a firma canonica sono
      // un vettore di malleabilita'. OpenSSL, e quindi Node, non normalizza S:
      // circa META' delle firme vere finisce li' dentro. Con l'impostazione
      // predefinita questa pagina avrebbe scritto "documento non integro" su
      // un rapporto su due, tutti genuini. Misurato: 23 firme su 40.
      // Qui non si canonicalizza niente e non si accettano firme al posto di
      // altre: si verifica un ECDSA prodotto da OpenSSL, e va accettato come
      // lo accetta OpenSSL.
      return p256.verify(byteFirma, impronta, puntoDaPem(pem), {
        format: 'der',
        prehash: false,
        lowS: false,
      });
    } catch {
      return false;
    }
  }
}

export function createVerify(algoritmo: string): Verify {
  if (algoritmo.toLowerCase().replace('-', '') !== 'sha256') {
    throw new Error(`node-crypto-shim: algoritmo non previsto: ${algoritmo}`);
  }
  return new Verify();
}

export default { createHash, createVerify };
