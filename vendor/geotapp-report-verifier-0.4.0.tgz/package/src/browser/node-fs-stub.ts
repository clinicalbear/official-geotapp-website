/**
 * Sostituto di `node:fs/promises` per la build da browser.
 *
 * Il lettore da ZIP importa `fs` per la variante che legge da percorso. Nel
 * browser quella variante non si usa mai: si legge il file scelto dall'utente
 * e si passa direttamente `readReportFromZipBuffer`. Lo stub esiste solo per
 * non trascinare Node dentro il bundle, e se qualcuno lo chiamasse per sbaglio
 * deve rompersi in modo evidente invece che silenzioso.
 */
function nonDisponibile(): never {
  throw new Error(
    'Lettura da percorso non disponibile nel browser: usare readReportFromZipBuffer',
  );
}

export const readFile = nonDisponibile;
export const readdir = nonDisponibile;
export const stat = nonDisponibile;
export default { readFile, readdir, stat };
