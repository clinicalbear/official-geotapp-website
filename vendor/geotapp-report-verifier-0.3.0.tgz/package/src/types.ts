// ─── Raw parsed JSON shapes ────────────────────────────────────────────────

export interface GpsCoords {
  latitude: number | null;
  longitude: number | null;
}

export interface RawEvent {
  eventId: string;
  timestamp: string;           // ISO-8601 UTC
  type: string;
  user: string;
  gps: GpsCoords;
  description: string;
  previousEventHash: string;
  eventHash: string;
  [key: string]: unknown;      // extra fields preserved but not hashed
}

export interface PhotoMeta {
  photoId: string;
  photoUrl?: string;
  storagePath?: string;
  fileSha256?: string;         // lowercase hex, may be absent in legacy
  fileSizeBytes?: number;
  missingFile?: boolean;
}

export interface RawProof {
  proofId: string;
  timestamp: string;           // ISO-8601 UTC  (proofTimestamp in meta)
  photosMeta?: PhotoMeta[];
  photoUrls?: string[];
  [key: string]: unknown;
}

export interface HistoryJson {
  reportVersion?: string;
  generatedAt?: string;
  timelineHash?: string;
  photosBundleHash?: string;
  summary?: Record<string, unknown>;
  project?: Record<string, unknown>;
  events: RawEvent[];
}

export interface ReportMeta {
  reportVersion?: string;
  reportSealVersion?: string;
  version?: string;
  projectId?: string;
  projectName?: string;
  companyId?: string;
  generatedAt?: string;
  eventsCount?: number;
  photosCount?: number;
  techniciansCount?: number;
  hash?: string;               // SHA-256 of history.json bytes
  timelineHash?: string;
  photosBundleHash?: string;
  archiveProjectRootHash?: string | null;
  reportRootHash?: string;
  integrityLevel?: 'full' | 'partial' | 'legacy' | 'invalid';
  integrityNotes?: string[];
  photoHashCoverage?: {
    strongFingerprintCount: number;
    legacyFallbackCount: number;
  };
  archiveSeal?: ArchiveSeal;
  verification?: Record<string, unknown>;
}

export interface ArchiveSeal {
  sealed?: boolean;
  sealedAt?: string;
  sealVersion?: string;
  projectId?: string;
  companyId?: string;
  eventsCount?: number;
  photosCount?: number;
  techniciansCount?: number;
  timelineHash?: string;
  photosBundleHash?: string;
  projectRootHash?: string;    // = archiveProjectRootHash in report_meta
  photoHashCoverage?: {
    strongFingerprintCount: number;
    legacyFallbackCount: number;
  };
}

export interface SealJson {
  version: string;              // "2.0"
  algorithm: string;            // "ES256"
  canonicalizationMethod: string;
  signedAt: string;             // ISO-8601 UTC
  issuer: string;               // "GeoTapp Flow"
  issuerType: string;           // "platform"
  keyId: string;                // "geotapp-seal-2026-v1"
  signedRootHash: string;       // sha256 hex of the signed rootPayload
  signature?: string;           // ECDSA P-256 hex — absent in unsigned seals
  companyId: string;
  reportId: string;
  projectId: string;
  // Payload fields stored for verifier reconstruction of signed payload
  eventsCount?: number;
  photosCount?: number;
  techniciansCount?: number;
  timelineHash?: string;
  photosBundleHash?: string;
  sealVersion?: string;
  /**
   * SHA-256 of the readable PDF delivered to the client.
   *
   * Part of the signed payload from sealVersion 2.1: without it the PDF was the
   * weak link (retouch the PDF and the package still verifies itself).
   */
  pdfSha256?: string;
}

// ─── Normalized shapes (built by build-context.ts) ─────────────────────────

export interface NormalizedEvent {
  eventId: string;
  timestamp: string;
  type: string;
  user: string;
  gps: GpsCoords;
  description: string;
  storedPreviousHash: string;
  storedEventHash: string;
  originalIndex: number;
}

export interface NormalizedTimelineEvent {
  eventId: string;
  timestamp: string;
  type: string;
  user: string;
  gps: GpsCoords;
  description: string;
}

export interface NormalizedPhoto {
  proofId: string;
  proofTimestamp: string;      // UTC ISO-8601
  photoOrder: number;          // 1-indexed
  photoId: string;
  storagePath: string;
  sourceUrl: string;
  fileSha256: string;          // empty string if absent
  missingFile: boolean;
}

// ─── SDK I/O types ──────────────────────────────────────────────────────────

export interface ReportArtifact {
  historyJson: HistoryJson;
  reportMeta: ReportMeta | null;
  sealJson: SealJson | null;            // null for legacy/pre-v2 reports
  historyJsonBytes: Uint8Array;
  photoFiles: Map<string, Uint8Array>;  // filename → bytes
}

export interface VerificationContext {
  artifact: ReportArtifact;
  events: NormalizedEvent[];
  timelineEvents: NormalizedTimelineEvent[];
  photos: NormalizedPhoto[];
  historyHash: string;
  timelineHashExpected: string | null;
  photosBundleHashExpected: string | null;
  summary: {
    eventsCount: number;
    photosCount: number;
    techniciansCount: number;
  };
}

export interface CheckResult {
  ok: boolean;
  skipped?: boolean;
  warnings: string[];
  errors: string[];
  details?: Record<string, unknown>;
}

export interface VerificationResult {
  status: 'valid' | 'degraded' | 'invalid';
  integrityLevel: 'full' | 'partial' | 'legacy' | 'invalid';
  reportVersion: string;
  reportSealVersion: string;

  // v2.0 fields — populated for all reports, null/absent for legacy
  signatureStatus: 'verified' | 'invalid' | 'absent';
  sealStatus: 'sealed' | 'hash-only' | 'absent';
  issuerDisplayName: string | null;
  companyIdentity: {
    companyId: string | null;
    companyName: string | null;
    reportId: string | null;
  };
  verificationMode: 'local' | 'online';

  checks: {
    zipStructure: CheckResult;
    historyJson: CheckResult;
    reportMeta: CheckResult;
    eventHashChain: CheckResult;
    timelineHash: CheckResult;
    photosBundleHash: CheckResult;
    photoFiles: CheckResult;
    reportRootHash: CheckResult;
    archiveSeal: CheckResult;
    signatureVerification: CheckResult;
    serverTimestamp: CheckResult;
  };
  warnings: string[];
  errors: string[];
  summary: {
    eventsCount: number;
    photosCount: number;
    missingPhotos: number;
    hashMismatches: number;
  };
}
