import type {
  ReportArtifact, VerificationContext,
  NormalizedEvent, NormalizedTimelineEvent, NormalizedPhoto,
  RawEvent,
} from './types.js';
import { sha256HexBytes } from './canonical.js';

/**
 * Normalize a timestamp for hash computation.
 *
 * New reports (v1.1+): history.json stores timestamps in UTC with Z suffix
 * (e.g. "2026-03-20T16:44:28.080Z") — same value Dart used for hashing.
 * We pass them through Date.toISOString() for consistent formatting.
 *
 * Legacy reports store timestamps in Italian local time without Z
 * (e.g. "2026-03-20T17:44:28.080").  Dart hashed these after converting
 * to UTC via DateTime.toUtc().  Italy uses CET (UTC+1) or CEST (UTC+2).
 * Since JS `new Date()` on a UTC server treats no-Z strings as UTC,
 * we must manually apply the Italy offset to reconstruct the UTC value
 * that Dart computed.
 */
function normalizeTimestamp(raw: string): string {
  if (!raw) return '';
  // Already has timezone info (Z or +offset) → normalize to UTC ISO
  if (/[Zz]$/.test(raw) || /[+-]\d{2}:\d{2}$/.test(raw)) {
    const d = new Date(raw);
    if (!isNaN(d.getTime())) return d.toISOString();
    return raw;
  }
  // No timezone suffix → Italian local time.
  // Determine CET (UTC+1) vs CEST (UTC+2) from the date itself.
  // CEST runs from last Sunday of March to last Sunday of October.
  const d = new Date(raw + 'Z'); // parse as UTC first to get month/day
  if (isNaN(d.getTime())) return raw;
  const year = d.getUTCFullYear();
  const month = d.getUTCMonth(); // 0-based
  // Last Sunday of March
  const marchLast = new Date(Date.UTC(year, 2, 31));
  marchLast.setUTCDate(31 - marchLast.getUTCDay());
  marchLast.setUTCHours(1, 0, 0, 0); // transition at 01:00 UTC
  // Last Sunday of October
  const octLast = new Date(Date.UTC(year, 9, 31));
  octLast.setUTCDate(31 - octLast.getUTCDay());
  octLast.setUTCHours(1, 0, 0, 0);
  const isCEST = d.getTime() >= marchLast.getTime() && d.getTime() < octLast.getTime();
  const offsetHours = isCEST ? 2 : 1;
  // Subtract the offset to get UTC
  const utc = new Date(d.getTime() - offsetHours * 3600_000);
  return utc.toISOString();
}

export function buildContext(artifact: ReportArtifact): VerificationContext {
  const { historyJson, reportMeta, historyJsonBytes } = artifact;

  // ── Sort events: timestamp → eventId → type → originalIndex ──────────────
  const events: NormalizedEvent[] = historyJson.events.map((e, i) => ({
    eventId: String(e.eventId ?? ''),
    timestamp: normalizeTimestamp(String(e.timestamp ?? '')),
    type: String(e.type ?? ''),
    user: String(e.user ?? ''),
    gps: {
      latitude: e.gps?.latitude ?? null,
      longitude: e.gps?.longitude ?? null,
    },
    description: String(e.description ?? ''),
    storedPreviousHash: String(e.previousEventHash ?? ''),
    storedEventHash: String(e.eventHash ?? ''),
    originalIndex: i,
  }));

  events.sort((a, b) => {
    if (a.timestamp !== b.timestamp) return a.timestamp < b.timestamp ? -1 : 1;
    if (a.eventId !== b.eventId) return a.eventId < b.eventId ? -1 : 1;
    if (a.type !== b.type) return a.type < b.type ? -1 : 1;
    return a.originalIndex - b.originalIndex;
  });

  // ── Timeline events (reduced payload) ────────────────────────────────────
  const timelineEvents: NormalizedTimelineEvent[] = events.map((e) => ({
    eventId: e.eventId,
    timestamp: e.timestamp,
    type: e.type,
    user: e.user,
    gps: e.gps,
    description: e.description,
  }));

  // ── Photos (extracted from proof events via photosMeta) ───────────────────
  // Photos are embedded in history.json events of type 'proof' as photosMeta.
  const photos: NormalizedPhoto[] = [];
  for (const rawEvent of historyJson.events) {
    if (rawEvent.type !== 'proof') continue;
    // Photos may be in `photosMeta` (v1) or `metadata.photoFiles` (v1.1+)
    const rawMeta = rawEvent as RawEvent & { photosMeta?: unknown[]; metadata?: Record<string, unknown> };
    const meta: unknown[] = Array.isArray(rawMeta.photosMeta)
      ? rawMeta.photosMeta
      : Array.isArray(rawMeta.metadata?.['photoFiles'])
        ? rawMeta.metadata!['photoFiles'] as unknown[]
        : [];
    if (!meta.length) continue;
    for (let i = 0; i < meta.length; i++) {
      const pm = meta[i] as Record<string, unknown>;
      photos.push({
        proofId: String(rawEvent.eventId ?? ''),
        proofTimestamp: normalizeTimestamp(String(rawEvent.timestamp ?? '')),
        photoOrder: i + 1,
        photoId: String(pm['photoId'] ?? ''),
        storagePath: String(pm['storagePath'] ?? ''),
        sourceUrl: String(pm['photoUrl'] ?? pm['sourceUrl'] ?? ''),
        fileSha256: String(pm['fileSha256'] ?? '').toLowerCase(),
        missingFile: pm['missingFile'] === true,
      });
    }
  }

  // Sort photos: proofTimestamp → proofId → photoOrder
  photos.sort((a, b) => {
    if (a.proofTimestamp !== b.proofTimestamp)
      return a.proofTimestamp < b.proofTimestamp ? -1 : 1;
    if (a.proofId !== b.proofId) return a.proofId < b.proofId ? -1 : 1;
    return a.photoOrder - b.photoOrder;
  });

  // ── Expected hashes — prefer report_meta over history.json ───────────────
  const timelineHashExpected =
    reportMeta?.timelineHash ?? historyJson.timelineHash ?? null;
  const photosBundleHashExpected =
    reportMeta?.photosBundleHash ?? historyJson.photosBundleHash ?? null;

  // ── Summary ───────────────────────────────────────────────────────────────
  const summary = {
    eventsCount: reportMeta?.eventsCount ?? historyJson.events.length,
    photosCount: reportMeta?.photosCount ?? photos.length,
    techniciansCount: reportMeta?.techniciansCount ?? 0,
  };

  return {
    artifact,
    events,
    timelineEvents,
    photos,
    historyHash: sha256HexBytes(historyJsonBytes),
    timelineHashExpected,
    photosBundleHashExpected,
    summary,
  };
}
