<?php
/**
 * Plugin Name: GeoTap SaaS Integration
 * Plugin URI: https://geotapp.com
 * Description: Integrates the GeoTap SaaS application directly into the WordPress admin dashboard.
 * Version: 1.0.0
 * Author: Black Shadow Group
 * Author URI: https://blackshadowgroup.com
 * License: GPL2
 */

// Prevent direct access to the file
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Register the admin menu page.
 */
function geotap_saas_add_admin_menu() {
    add_menu_page(
        'GeoTap SaaS',           // Page title
        'GeoTap SaaS',           // Menu title
        'manage_options',        // Capability required (admins only by default)
        'geotap-saas',           // Menu slug
        'geotap_saas_render_page', // Callback function
        'dashicons-location',    // Icon (location pin seems appropriate for GeoTap)
        6                        // Position (below Posts/Media)
    );
}
add_action( 'admin_menu', 'geotap_saas_add_admin_menu' );

/**
 * Render the admin page content.
 */
function geotap_saas_render_page() {
    ?>
    <div class="wrap" style="margin: 0; padding: 0; overflow: hidden;">
        <style>
            /* Reset some WP admin styles for the container to maximize space */
            #wpbody-content { padding-bottom: 0px !important; }
            .auto-fold #wpcontent { padding-left: 0px !important; }
            
            /* The actual iframe container */
            #geotap_saas_container {
                width: 100%;
                height: calc(100vh - 32px); /* Subtract WP admin bar height approximately */
                border: 0;
            }
            
            /* Responsive adjustments if needed */
            @media screen and (max-width: 782px) {
                #geotap_saas_container {
                    height: calc(100vh - 46px);
                }
            }
        </style>
        
        <iframe 
            id="geotap_saas_container"
            src="https://geotap-v2.web.app" 
            title="GeoTap SaaS"
            allow="geolocation; microphone; camera; midi; vr; accelerometer; gyroscope; payment; ambient-light-sensor; encrypted-media; usb"
            scrolling="yes"
            frameborder="0"
        ></iframe>
    </div>
    <?php
}
