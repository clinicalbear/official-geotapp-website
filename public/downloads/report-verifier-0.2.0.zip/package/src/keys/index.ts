import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

/**
 * GeoTapp public keys for seal verification, keyed by keyId.
 *
 * To rotate keys:
 *   1. Generate new keypair, add new .pem file to this directory
 *   2. Add entry here: 'geotapp-seal-YYYY-v1' → readFileSync(...)
 *   3. Update SEAL_KEY_ID in geotapp-flow/functions/index.js
 *   4. Old keyId entries must remain for verification of existing reports
 */
export const GEOTAPP_PUBLIC_KEYS: Record<string, string> = {
  'geotapp-seal-2026-v1': readFileSync(
    path.join(__dirname, 'geotapp-seal-2026-v1.pem'),
    'utf8',
  ),
};

export function getPublicKeyForSeal(keyId: string | undefined): string | null {
  if (!keyId) return null;
  return GEOTAPP_PUBLIC_KEYS[keyId] ?? null;
}
