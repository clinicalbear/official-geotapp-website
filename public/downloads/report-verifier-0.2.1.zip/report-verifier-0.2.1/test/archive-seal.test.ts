import { describe, it, expect } from 'vitest';
import { checkArchiveSeal } from '../src/checkers/archive-seal.js';
import { buildContext } from '../src/build-context.js';
import { buildValidArtifact } from './fixtures/factory.js';
import type { SealJson } from '../src/types.js';

/** Minimal SealJson that satisfies the type for cross-check tests. */
function makeSealJson(overrides: Partial<SealJson> = {}): SealJson {
  return {
    signedRootHash: 'root-hash-abc',
    signedAt: '2026-03-17T10:00:00.000Z',
    timelineHash: 'timeline-hash-abc',
    photosBundleHash: 'photos-hash-abc',
    sealVersion: '1.0',
    ...overrides,
  } as SealJson;
}

describe('checkArchiveSeal', () => {
  it('skips when sealJson is null', () => {
    const artifact = buildValidArtifact({ eventsCount: 2 });
    // Default artifact has sealJson: null
    const ctx = buildContext(artifact);
    const result = checkArchiveSeal(ctx);
    expect(result.skipped).toBe(true);
    expect(result.ok).toBe(true);
  });

  it('passes when seal hashes match report_meta', () => {
    const artifact = buildValidArtifact({ eventsCount: 2 });
    const meta = artifact.reportMeta!;
    artifact.sealJson = makeSealJson({
      signedRootHash: 'root-hash-abc',
      timelineHash: meta.timelineHash,
      photosBundleHash: meta.photosBundleHash,
    });
    meta.archiveProjectRootHash = 'root-hash-abc';
    const ctx = buildContext(artifact);
    expect(checkArchiveSeal(ctx).ok).toBe(true);
  });

  it('errors when seal timelineHash differs from report_meta', () => {
    const artifact = buildValidArtifact({ eventsCount: 2 });
    const meta = artifact.reportMeta!;
    artifact.sealJson = makeSealJson({
      signedRootHash: 'root-hash-abc',
      timelineHash: 'wrong-timeline-hash',
      photosBundleHash: meta.photosBundleHash,
    });
    meta.archiveProjectRootHash = 'root-hash-abc';
    const ctx = buildContext(artifact);
    const result = checkArchiveSeal(ctx);
    expect(result.ok).toBe(false);
    expect(result.errors.some(e => e.includes('timelineHash'))).toBe(true);
  });
});
