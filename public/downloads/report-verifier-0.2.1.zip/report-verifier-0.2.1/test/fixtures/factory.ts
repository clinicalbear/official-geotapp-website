import fs from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import { generateKeyPairSync, createSign } from 'node:crypto';
import { canonicalJson, sha256Hex } from '../../src/canonical.js';
import type { ReportArtifact, RawEvent, SealJson } from '../../src/types.js';

// ─── Minimal dir factory (used by reader tests) ───────────────────────────────

interface MinimalFactoryOptions {
  omitHistory?: boolean;
  omitReportMeta?: boolean;
}

export async function buildMinimalArtifactDir(opts: MinimalFactoryOptions = {}): Promise<string> {
  const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'geotapp-test-'));

  if (!opts.omitHistory) {
    await fs.mkdir(path.join(dir, 'data'), { recursive: true });
    await fs.writeFile(
      path.join(dir, 'data', 'history.json'),
      JSON.stringify({ reportVersion: '1.1', events: [], generatedAt: '2026-01-01T00:00:00.000Z' })
    );
  }

  if (!opts.omitReportMeta) {
    await fs.mkdir(path.join(dir, 'metadata'), { recursive: true });
    await fs.writeFile(
      path.join(dir, 'metadata', 'report_meta.json'),
      JSON.stringify({ reportVersion: '1.1', reportSealVersion: '1.0' })
    );
  }

  return dir;
}

// ─── Valid artifact factory ───────────────────────────────────────────────────

interface ValidArtifactOptions {
  eventsCount?: number;
}

export function buildValidArtifact(opts: ValidArtifactOptions = {}): ReportArtifact {
  const { eventsCount = 3 } = opts;

  const events: RawEvent[] = [];
  let previousEventHash = '';

  for (let i = 0; i < eventsCount; i++) {
    const eventId = `evt-${String(i).padStart(3, '0')}`;
    // Use fixed UTC times to avoid timezone issues
    const timestamp = new Date(Date.UTC(2026, 0, 15, 9, i)).toISOString();
    const payload = {
      eventId,
      timestamp,
      type: 'proof',
      user: 'test.user',
      gps: { latitude: null, longitude: null },
      description: `Event ${i}`,
      previousEventHash,
    };
    const eventHash = sha256Hex(canonicalJson(payload));
    events.push({
      ...payload,
      eventHash,
      title: `Event ${i}`,
      category: 'proof',
      actor: null,
      latitude: null,
      longitude: null,
      photoPaths: [],
      metadata: {},
    });
    previousEventHash = eventHash;
  }

  // Compute timelineHash: same chain on reduced event payloads
  let tlPrevHash = '';
  for (const e of events) {
    const payload = {
      eventId: e.eventId,
      timestamp: e.timestamp,
      type: e.type,
      user: e.user,
      gps: e.gps,
      description: e.description,
      previousEventHash: tlPrevHash,
    };
    tlPrevHash = sha256Hex(canonicalJson(payload));
  }
  // Zero-event fallback matches Cloud Function and computeTimelineHash() fix.
  const timelineHash = tlPrevHash || sha256Hex('empty_timeline_v1');
  const photosBundleHash = sha256Hex(canonicalJson([]));

  const historyJson = {
    reportVersion: '1.1',
    generatedAt: new Date().toISOString(),
    timelineHash,
    photosBundleHash,
    summary: { eventsCount, photosCount: 0, techniciansCount: 1 },
    project: {},
    events,
  };

  const historyJsonBytes = new TextEncoder().encode(JSON.stringify(historyJson));
  const historyHash = sha256Hex(new TextDecoder().decode(historyJsonBytes));

  // Compute reportRootHash
  const rootPayload = {
    historyHash,
    summary: historyJson.summary,
    eventsCount,
    photosCount: 0,
    techniciansCount: 1,
    timelineHash,
    photosBundleHash,
    archiveProjectRootHash: null,
    reportVersion: '1.1',
    reportSealVersion: '1.0',
  };
  const reportRootHash = sha256Hex(canonicalJson(rootPayload));

  return {
    historyJson,
    reportMeta: {
      reportVersion: '1.1',
      reportSealVersion: '1.0',
      eventsCount,
      photosCount: 0,
      techniciansCount: 1,
      hash: historyHash,
      timelineHash,
      photosBundleHash,
      archiveProjectRootHash: null,
      reportRootHash,
      integrityLevel: 'partial',   // no archive seal
    },
    sealJson: null,
    historyJsonBytes,
    photoFiles: new Map(),
  };
}

// ─── Tamper helpers ───────────────────────────────────────────────────────────

export function tamperEventHash(artifact: ReportArtifact, index: number): ReportArtifact {
  const events = [...artifact.historyJson.events];
  events[index] = { ...events[index], eventHash: 'tampered-hash' };
  return { ...artifact, historyJson: { ...artifact.historyJson, events } };
}

export function tamperTimelineHash(artifact: ReportArtifact): ReportArtifact {
  return {
    ...artifact,
    reportMeta: artifact.reportMeta
      ? { ...artifact.reportMeta, timelineHash: 'tampered-timeline' }
      : null,
  };
}

export function tamperRootHash(artifact: ReportArtifact): ReportArtifact {
  return {
    ...artifact,
    reportMeta: artifact.reportMeta
      ? { ...artifact.reportMeta, reportRootHash: 'tampered-root' }
      : null,
  };
}

export function buildLegacyArtifact(): ReportArtifact {
  // Legacy: no reportVersion, no hashes
  const historyJson = {
    events: [
      {
        eventId: 'old-1',
        timestamp: '2024-06-01T08:00:00.000Z',
        type: 'proof',
        user: 'legacy.user',
        gps: { latitude: null, longitude: null },
        description: 'Old event',
        previousEventHash: '',
        eventHash: '',
        title: '',
        category: 'proof',
        actor: null,
        latitude: null,
        longitude: null,
        photoPaths: [],
        metadata: {},
      },
    ],
  };
  const historyJsonBytes = new TextEncoder().encode(JSON.stringify(historyJson));
  return {
    historyJson,
    reportMeta: null,
    sealJson: null,
    historyJsonBytes,
    photoFiles: new Map(),
  };
}

// ─── Test keypair for sealed artifact tests ───────────────────────────────────
// NOT the production key. Used only in tests.
export const TEST_KEY_PAIR = generateKeyPairSync('ec', {
  namedCurve: 'P-256',
  publicKeyEncoding: { type: 'spki', format: 'pem' },
  privateKeyEncoding: { type: 'pkcs8', format: 'pem' },
});

// ─── Sealed artifact factory ─────────────────────────────────────────────────
// Produces a valid v2.0 artifact with a correct ECDSA signature,
// using the TEST_KEY_PAIR (not the production key).
export function buildSealedArtifact(opts: ValidArtifactOptions = {}): ReportArtifact {
  const artifact = buildValidArtifact(opts);
  const meta = artifact.reportMeta!;

  const projectId = meta.projectId ?? 'test-proj';
  const companyId = meta.companyId ?? 'test-company';
  const sealedAt = meta.generatedAt ?? '2026-03-17T10:00:00.000Z';

  // Must match exactly the rootPayload structure in:
  //   geotapp-flow/functions/index.js → computeArchiveSealForProject()
  const rootPayload = {
    projectId,
    companyId,
    sealedAt,
    eventsCount: meta.eventsCount ?? 0,
    photosCount: meta.photosCount ?? 0,
    techniciansCount: meta.techniciansCount ?? 0,
    timelineHash: meta.timelineHash ?? '',
    photosBundleHash: meta.photosBundleHash ?? '',
    sealVersion: '1.0',
  };

  const sign = createSign('SHA256');
  sign.update(canonicalJson(rootPayload), 'utf8');
  const signature = sign.sign(TEST_KEY_PAIR.privateKey, 'hex');

  const sealJson: SealJson = {
    version: '2.0',
    algorithm: 'ES256',
    canonicalizationMethod: 'canonical-json-v1',
    signedAt: sealedAt,
    issuer: 'GeoTapp Flow',
    issuerType: 'platform',
    keyId: 'geotapp-seal-2026-v1',   // matching the production keyId
    signedRootHash: sha256Hex(canonicalJson(rootPayload)),
    signature,
    companyId,
    reportId: `rpt_${companyId}_${projectId}`,
    projectId,
    eventsCount: rootPayload.eventsCount,
    photosCount: rootPayload.photosCount,
    techniciansCount: rootPayload.techniciansCount,
    timelineHash: rootPayload.timelineHash,
    photosBundleHash: rootPayload.photosBundleHash,
    sealVersion: rootPayload.sealVersion,
  };

  return { ...artifact, sealJson };
}
