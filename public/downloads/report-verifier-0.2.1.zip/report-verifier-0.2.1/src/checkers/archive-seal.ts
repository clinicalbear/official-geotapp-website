import type { VerificationContext, CheckResult } from '../types.js';

/**
 * Cross-checks the hashes stored in seal.json against those in report_meta.json.
 *
 * Previously this read reportMeta.archiveSeal (a nested object that Dart's
 * buildReportMeta() never populates) — it was dead code that always skipped.
 * Now it correctly compares sealJson fields against the top-level reportMeta fields.
 */
export function checkArchiveSeal(ctx: VerificationContext): CheckResult {
  const { reportMeta, sealJson } = ctx.artifact;

  if (!sealJson) {
    return {
      ok: true,
      skipped: true,
      warnings: ['seal.json not present — archive seal cross-check skipped'],
      errors: [],
      details: { archiveSealPresent: false },
    };
  }

  if (!reportMeta) {
    return {
      ok: true,
      skipped: true,
      warnings: ['report_meta.json not present — archive seal cross-check skipped'],
      errors: [],
      details: { archiveSealPresent: true },
    };
  }

  const errors: string[] = [];

  // sealJson.timelineHash must match reportMeta.timelineHash (both derived from the same chain)
  if (sealJson.timelineHash !== undefined && sealJson.timelineHash !== reportMeta.timelineHash) {
    errors.push(
      `timelineHash mismatch (seal vs report_meta): seal="${String(sealJson.timelineHash).slice(0, 16)}…" meta="${String(reportMeta.timelineHash).slice(0, 16)}…"`
    );
  }

  // sealJson.photosBundleHash must match reportMeta.photosBundleHash
  if (sealJson.photosBundleHash !== undefined && sealJson.photosBundleHash !== reportMeta.photosBundleHash) {
    errors.push(
      `photosBundleHash mismatch (seal vs report_meta): seal="${String(sealJson.photosBundleHash).slice(0, 16)}…" meta="${String(reportMeta.photosBundleHash).slice(0, 16)}…"`
    );
  }

  // sealJson.signedRootHash must match reportMeta.archiveProjectRootHash
  if (
    sealJson.signedRootHash &&
    reportMeta.archiveProjectRootHash &&
    sealJson.signedRootHash !== reportMeta.archiveProjectRootHash
  ) {
    errors.push(
      `signedRootHash mismatch (seal vs report_meta): seal="${sealJson.signedRootHash.slice(0, 16)}…" meta="${reportMeta.archiveProjectRootHash.slice(0, 16)}…"`
    );
  }

  return {
    ok: errors.length === 0,
    errors,
    warnings: [],
    details: {
      archiveSealPresent: true,
      archiveSealMatched: errors.length === 0,
    },
  };
}
