import type { VerificationContext, CheckResult, NormalizedPhoto } from '../types.js';
import { canonicalJson, sha256Hex } from '../canonical.js';

export function checkPhotosBundleHash(ctx: VerificationContext): CheckResult {
  if (!ctx.photosBundleHashExpected) {
    return {
      ok: true,
      skipped: true,
      warnings: ['photosBundleHash not present in metadata — skipping (legacy report)'],
      errors: [],
    };
  }

  const computed = computePhotosBundleHash(ctx.photos);

  if (computed !== ctx.photosBundleHashExpected) {
    return {
      ok: false,
      errors: [
        `photosBundleHash mismatch: computed="${computed.slice(0, 16)}…" expected="${ctx.photosBundleHashExpected.slice(0, 16)}…"`,
      ],
      warnings: [],
      details: { computed, expected: ctx.photosBundleHashExpected },
    };
  }

  return { ok: true, errors: [], warnings: [], details: { computed } };
}

export function computePhotosBundleHash(photos: NormalizedPhoto[]): string {
  const digestInput = photos.map((p) => {
    let fingerprint: string;
    let fingerprintType: string;

    if (p.fileSha256 && p.fileSha256.length > 0) {
      fingerprint = p.fileSha256;          // already lowercased in build-context
      fingerprintType = 'sha256';
    } else {
      // Legacy fallback: must exactly match Dart generator's _buildPhotoIntegrityEntry()
      // Fields: legacy, proofId, proofTimestamp, photoOrder, photoId, storagePath, sourceUrl
      fingerprint = sha256Hex(
        canonicalJson({
          legacy: true,
          proofId: p.proofId,
          proofTimestamp: p.proofTimestamp,
          photoOrder: p.photoOrder,
          photoId: p.photoId,
          storagePath: p.storagePath,
          sourceUrl: p.sourceUrl,
        })
      );
      fingerprintType = 'legacy';
    }

    return {
      proofId: p.proofId,
      proofTimestamp: p.proofTimestamp,
      photoOrder: p.photoOrder,
      photoId: p.photoId,
      fingerprint,
      fingerprintType,
      missingFile: p.missingFile,
    };
  });

  // Sort by 5 keys after fingerprints are computed — matches Dart generator's
  // normalized.sort() in _computePhotosBundleHash() (proofTimestamp → proofId
  // → photoOrder → photoId → fingerprint).  Previously the verifier sorted by
  // only 3 keys in build-context.ts *before* fingerprints were known, causing
  // a hash mismatch for any report with photos from multiple proof events.
  digestInput.sort((a, b) => {
    if (a.proofTimestamp !== b.proofTimestamp)
      return a.proofTimestamp < b.proofTimestamp ? -1 : 1;
    if (a.proofId !== b.proofId) return a.proofId < b.proofId ? -1 : 1;
    if (a.photoOrder !== b.photoOrder) return a.photoOrder - b.photoOrder;
    if (a.photoId !== b.photoId) return a.photoId < b.photoId ? -1 : 1;
    return a.fingerprint < b.fingerprint ? -1 : a.fingerprint > b.fingerprint ? 1 : 0;
  });

  return sha256Hex(canonicalJson(digestInput));
}
