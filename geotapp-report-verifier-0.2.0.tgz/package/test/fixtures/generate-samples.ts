#!/usr/bin/env node
import JSZip from 'jszip';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { buildValidArtifact, buildLegacyArtifact } from './factory.js';
import type { ReportArtifact } from '../../src/types.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

async function artifactToZip(artifact: ReportArtifact): Promise<Buffer> {
  const zip = new JSZip();
  // Use historyJsonBytes directly so the hash baked into reportMeta stays valid
  zip.file('data/history.json', artifact.historyJsonBytes);
  if (artifact.reportMeta) {
    zip.file('metadata/report_meta.json', JSON.stringify(artifact.reportMeta, null, 2));
  }
  zip.file('report.html', '<html><body>GeoTapp Report</body></html>');
  for (const [name, bytes] of artifact.photoFiles) {
    zip.file(`photos/${name}`, bytes);
  }
  return zip.generateAsync({ type: 'nodebuffer', compression: 'DEFLATE' });
}

async function main() {
  const outDir = __dirname;

  // Valid full report (partial integrity — no archive seal)
  const validArtifact = buildValidArtifact({ eventsCount: 5 });
  await fs.writeFile(
    path.join(outDir, 'sample-valid-full.zip'),
    await artifactToZip(validArtifact)
  );
  console.log('✔ sample-valid-full.zip');

  // Legacy report (no hashes, no report_meta)
  const legacyArtifact = buildLegacyArtifact();
  await fs.writeFile(
    path.join(outDir, 'sample-legacy.zip'),
    await artifactToZip(legacyArtifact)
  );
  console.log('✔ sample-legacy.zip');

  // Partial: valid hashes but no archive seal (same as valid full for now)
  const partialArtifact = buildValidArtifact({ eventsCount: 3 });
  await fs.writeFile(
    path.join(outDir, 'sample-partial.zip'),
    await artifactToZip(partialArtifact)
  );
  console.log('✔ sample-partial.zip');
}

main().catch(console.error);
