import { describe, it, expect } from 'vitest';
import { checkPhotosBundleHash } from '../src/checkers/photos-bundle-hash.js';
import { buildContext } from '../src/build-context.js';
import { buildValidArtifact } from './fixtures/factory.js';

describe('checkPhotosBundleHash', () => {
  it('passes for report with no photos (empty bundle)', () => {
    const ctx = buildContext(buildValidArtifact({ eventsCount: 2 }));
    expect(checkPhotosBundleHash(ctx).ok).toBe(true);
  });

  it('skips when no expected hash available', () => {
    const artifact = buildValidArtifact({ eventsCount: 1 });
    (artifact.reportMeta as any).photosBundleHash = undefined;
    artifact.historyJson.photosBundleHash = undefined;
    const ctx = buildContext(artifact);
    const result = checkPhotosBundleHash(ctx);
    expect(result.skipped).toBe(true);
  });

  it('fails when photosBundleHash is wrong', () => {
    const artifact = buildValidArtifact({ eventsCount: 2 });
    (artifact.reportMeta as any).photosBundleHash = 'bad-hash';
    const ctx = buildContext(artifact);
    expect(checkPhotosBundleHash(ctx).ok).toBe(false);
  });
});
