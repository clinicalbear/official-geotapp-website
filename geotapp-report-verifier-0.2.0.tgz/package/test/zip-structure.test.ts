import { describe, it, expect } from 'vitest';
import { checkZipStructure } from '../src/checkers/zip-structure.js';
import type { ReportArtifact } from '../src/types.js';

function makeArtifact(overrides?: Partial<ReportArtifact>): ReportArtifact {
  return {
    historyJson: { reportVersion: '1.1', events: [] },
    reportMeta: { reportVersion: '1.1', reportSealVersion: '1.0' },
    historyJsonBytes: new Uint8Array([1]),
    photoFiles: new Map(),
    ...overrides,
  };
}

describe('checkZipStructure', () => {
  it('passes when all required files present', () => {
    const result = checkZipStructure(makeArtifact());
    expect(result.ok).toBe(true);
    expect(result.errors).toHaveLength(0);
  });

  it('fails when report_meta absent in a modern report (has reportVersion)', () => {
    const result = checkZipStructure(makeArtifact({ reportMeta: null }));
    // non-legacy → report_meta is expected
    expect(result.ok).toBe(false);
    expect(result.errors.some(e => e.includes('report_meta.json'))).toBe(true);
  });

  it('warns but does not fail when report.html absent', () => {
    // report.html is never part of integrity verification
    const result = checkZipStructure(makeArtifact());
    // No error about report.html
    expect(result.errors.some(e => e.includes('report.html'))).toBe(false);
  });

  it('accepts extra files without error', () => {
    const artifact = makeArtifact();
    artifact.photoFiles.set('extra.jpg', new Uint8Array([0]));
    const result = checkZipStructure(artifact);
    expect(result.ok).toBe(true);
  });
});
