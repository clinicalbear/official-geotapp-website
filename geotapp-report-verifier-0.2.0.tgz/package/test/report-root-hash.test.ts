import { describe, it, expect } from 'vitest';
import { checkReportRootHash } from '../src/checkers/report-root-hash.js';
import { buildContext } from '../src/build-context.js';
import { buildValidArtifact } from './fixtures/factory.js';

describe('checkReportRootHash', () => {
  it('passes for a valid artifact', () => {
    const ctx = buildContext(buildValidArtifact({ eventsCount: 3 }));
    expect(checkReportRootHash(ctx).ok).toBe(true);
  });

  it('skips when reportMeta is null', () => {
    const artifact = buildValidArtifact({ eventsCount: 2 });
    artifact.reportMeta = null;
    const ctx = buildContext(artifact);
    expect(checkReportRootHash(ctx).skipped).toBe(true);
  });

  it('skips when reportRootHash absent in meta (legacy)', () => {
    const artifact = buildValidArtifact({ eventsCount: 2 });
    (artifact.reportMeta as any).reportRootHash = undefined;
    const ctx = buildContext(artifact);
    expect(checkReportRootHash(ctx).skipped).toBe(true);
  });

  it('fails when reportRootHash is corrupted', () => {
    const artifact = buildValidArtifact({ eventsCount: 2 });
    (artifact.reportMeta as any).reportRootHash = 'corrupted';
    const ctx = buildContext(artifact);
    expect(checkReportRootHash(ctx).ok).toBe(false);
  });

  it('handles null archiveProjectRootHash correctly', () => {
    const artifact = buildValidArtifact({ eventsCount: 2 });
    // archiveProjectRootHash is already null in buildValidArtifact
    const ctx = buildContext(artifact);
    expect(checkReportRootHash(ctx).ok).toBe(true);
  });
});
