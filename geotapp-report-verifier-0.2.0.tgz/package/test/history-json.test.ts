import { describe, it, expect } from 'vitest';
import { checkHistoryJson } from '../src/checkers/zip-structure.js';

describe('checkHistoryJson', () => {
  it('passes for valid history.json', () => {
    const result = checkHistoryJson({
      reportVersion: '1.1',
      events: [],
      generatedAt: '2026-01-01T00:00:00.000Z',
    });
    expect(result.ok).toBe(true);
  });

  it('passes for legacy minimal structure (no reportVersion)', () => {
    const result = checkHistoryJson({ events: [] });
    expect(result.ok).toBe(true);
    expect(result.warnings.some(w => w.toLowerCase().includes('legacy'))).toBe(true);
  });

  it('fails when events field is missing', () => {
    const result = checkHistoryJson({ reportVersion: '1.1' } as any);
    expect(result.ok).toBe(false);
    expect(result.errors.some(e => e.includes('events'))).toBe(true);
  });

  it('fails when events is not an array', () => {
    const result = checkHistoryJson({ reportVersion: '1.1', events: 'bad' } as any);
    expect(result.ok).toBe(false);
  });
});
