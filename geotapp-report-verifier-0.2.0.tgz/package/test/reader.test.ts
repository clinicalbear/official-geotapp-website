import { describe, it, expect } from 'vitest';
import { readReportFromFolder } from '../src/reader/folder-reader.js';
import { readReportFromZip } from '../src/reader/zip-reader.js';
import { buildMinimalArtifactDir } from './fixtures/factory.js';
import path from 'node:path';
import fs from 'node:fs/promises';

describe('folder-reader', () => {
  it('reads a valid report folder', async () => {
    const dir = await buildMinimalArtifactDir();
    const artifact = await readReportFromFolder(dir);
    expect(artifact.historyJson.events).toBeDefined();
    expect(artifact.reportMeta).not.toBeNull();
    expect(artifact.historyJsonBytes.length).toBeGreaterThan(0);
  });

  it('returns null reportMeta when metadata file absent', async () => {
    const dir = await buildMinimalArtifactDir({ omitReportMeta: true });
    const artifact = await readReportFromFolder(dir);
    expect(artifact.reportMeta).toBeNull();
  });

  it('throws on missing history.json', async () => {
    const dir = await buildMinimalArtifactDir({ omitHistory: true });
    await expect(readReportFromFolder(dir)).rejects.toThrow(/history\.json/);
  });
});

describe('zip-reader', () => {
  it('reads a valid report ZIP', async () => {
    const zipPath = path.resolve('test/fixtures/sample-valid-full.zip');
    // Skip if sample zip not yet created (will exist after Task 13)
    const exists = await fs.access(zipPath).then(() => true).catch(() => false);
    if (!exists) return;

    const artifact = await readReportFromZip(zipPath);
    expect(artifact.historyJson.events.length).toBeGreaterThan(0);
  });
});
