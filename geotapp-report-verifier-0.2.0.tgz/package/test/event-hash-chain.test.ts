import { describe, it, expect } from 'vitest';
import { checkEventHashChain } from '../src/checkers/event-hash-chain.js';
import { buildContext } from '../src/build-context.js';
import { buildValidArtifact } from './fixtures/factory.js';

describe('checkEventHashChain', () => {
  it('passes for a valid two-event chain', () => {
    const artifact = buildValidArtifact({ eventsCount: 2 });
    const ctx = buildContext(artifact);
    const result = checkEventHashChain(ctx);
    expect(result.ok).toBe(true);
    expect(result.details?.['verifiedCount']).toBe(2);
  });

  it('passes for zero events (empty report)', () => {
    const artifact = buildValidArtifact({ eventsCount: 0 });
    const ctx = buildContext(artifact);
    expect(checkEventHashChain(ctx).ok).toBe(true);
  });

  it('fails when eventHash of first event is wrong', () => {
    const artifact = buildValidArtifact({ eventsCount: 2 });
    // tamper: corrupt the first event's stored hash
    artifact.historyJson.events[0].eventHash = 'corrupted';
    const ctx = buildContext(artifact);
    const result = checkEventHashChain(ctx);
    expect(result.ok).toBe(false);
    expect(result.errors.some(e => e.includes('eventHash mismatch'))).toBe(true);
  });

  it('fails when previousEventHash linkage is broken', () => {
    const artifact = buildValidArtifact({ eventsCount: 3 });
    // tamper: corrupt second event's previousEventHash
    artifact.historyJson.events[1].previousEventHash = 'wrong-prev';
    const ctx = buildContext(artifact);
    const result = checkEventHashChain(ctx);
    expect(result.ok).toBe(false);
  });

  it('is deterministic: tie-breaking by originalIndex for equal timestamp+eventId+type', () => {
    const artifact = buildValidArtifact({ eventsCount: 0 });
    // Manually insert two events with the same sort key
    artifact.historyJson.events = [
      {
        eventId: 'x', timestamp: '2026-01-01T00:00:00.000Z', type: 'proof',
        user: 'u', gps: { latitude: null, longitude: null }, description: 'second',
        previousEventHash: '', eventHash: '',
      },
      {
        eventId: 'x', timestamp: '2026-01-01T00:00:00.000Z', type: 'proof',
        user: 'u', gps: { latitude: null, longitude: null }, description: 'first',
        previousEventHash: '', eventHash: '',
      },
    ];
    // Run buildContext twice and verify same sort order both times
    const ctx1 = buildContext(artifact);
    const ctx2 = buildContext(artifact);
    expect(ctx1.events[0].description).toBe(ctx2.events[0].description);
    expect(ctx1.events[1].description).toBe(ctx2.events[1].description);
  });
});
