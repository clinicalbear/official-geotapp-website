import { describe, it, expect } from 'vitest';
import { canonicalJson, sha256Hex, sha256HexBytes } from '../src/canonical.js';

describe('canonicalJson — null/undefined', () => {
  it('serializes null', () => {
    expect(canonicalJson(null)).toBe('null');
  });
  it('serializes undefined as null', () => {
    expect(canonicalJson(undefined)).toBe('null');
  });
});

describe('canonicalJson — booleans', () => {
  it('preserves true', () => expect(canonicalJson(true)).toBe('true'));
  it('preserves false', () => expect(canonicalJson(false)).toBe('false'));
});

describe('canonicalJson — strings', () => {
  it('preserves plain string', () => expect(canonicalJson('hello')).toBe('"hello"'));
  it('preserves unicode', () => expect(canonicalJson('café ☕')).toBe('"café ☕"'));
  it('escapes JSON-special chars', () => expect(canonicalJson('a"b')).toBe('"a\\"b"'));
});

describe('canonicalJson — numbers', () => {
  it('preserves integer', () => expect(canonicalJson(42)).toBe('42'));
  it('preserves zero', () => expect(canonicalJson(0)).toBe('0'));
  it('normalizes -0 to 0', () => expect(canonicalJson(-0)).toBe('0'));
  it('normalizes float with 12 decimal precision', () => {
    expect(canonicalJson(1.1)).toBe('1.1');
    expect(canonicalJson(1.123456789012345)).toBe('1.123456789012');
  });
  it('normalizes Infinity to null', () => expect(canonicalJson(Infinity)).toBe('null'));
  it('normalizes -Infinity to null', () => expect(canonicalJson(-Infinity)).toBe('null'));
  it('normalizes NaN to null', () => expect(canonicalJson(NaN)).toBe('null'));
});

describe('canonicalJson — arrays', () => {
  it('preserves array order', () => {
    expect(canonicalJson([3, 1, 2])).toBe('[3,1,2]');
  });
  it('recursively normalizes items', () => {
    expect(canonicalJson([undefined, null, -0])).toBe('[null,null,0]');
  });
});

describe('canonicalJson — objects', () => {
  it('sorts keys lexicographically', () => {
    expect(canonicalJson({ b: 1, a: 2 })).toBe('{"a":2,"b":1}');
  });
  it('sorts keys: uppercase before lowercase (plain sort)', () => {
    // JS default sort: 'B' < 'a' (uppercase sorts first)
    expect(canonicalJson({ a: 1, B: 2 })).toBe('{"B":2,"a":1}');
  });
  it('recursively canonicalizes values', () => {
    expect(canonicalJson({ x: { b: 1, a: 2 } })).toBe('{"x":{"a":2,"b":1}}');
  });
  it('preserves null values in objects', () => {
    expect(canonicalJson({ a: null })).toBe('{"a":null}');
  });
});

describe('canonicalJson — golden vectors (must match Dart generator output)', () => {
  it('event hash chain payload', () => {
    const payload = {
      eventId: 'evt-001',
      timestamp: '2026-01-15T09:00:00.000Z',
      type: 'proof',
      user: 'mario.rossi',
      gps: { latitude: 45.4654, longitude: 9.1866 },
      description: 'Sopralluogo completato',
      previousEventHash: '',
    };
    // Canonical: keys sorted alphabetically
    const result = canonicalJson(payload);
    const parsed = JSON.parse(result);
    const keys = Object.keys(parsed);
    expect(keys).toEqual([...keys].sort());
    // Known SHA-256 of this canonical form — pre-computed and frozen
    expect(sha256Hex(result)).toMatchSnapshot();
  });

  it('nested gps null values', () => {
    const payload = {
      eventId: 'evt-002',
      timestamp: '2026-01-15T09:01:00.000Z',
      type: 'sessionStart',
      user: 'luigi.verdi',
      gps: { latitude: null, longitude: null },
      description: '',
      previousEventHash: 'abc123',
    };
    expect(sha256Hex(canonicalJson(payload))).toMatchSnapshot();
  });
});

describe('sha256Hex', () => {
  it('known vector: empty string', () => {
    expect(sha256Hex('')).toBe(
      'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'
    );
  });
  it('known vector: "abc"', () => {
    // Verified with: echo -n 'abc' | sha256sum
    expect(sha256Hex('abc')).toBe(
      'ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad'
    );
  });
});

describe('sha256HexBytes', () => {
  it('matches sha256Hex for UTF-8 encoded string', async () => {
    const str = 'hello world';
    const bytes = new TextEncoder().encode(str);
    const { createHash } = await import('crypto');
    const expected = createHash('sha256').update(str, 'utf8').digest('hex');
    expect(sha256HexBytes(bytes)).toBe(expected);
  });
});
