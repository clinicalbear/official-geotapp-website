import { describe, it, expect } from 'vitest';
import { checkReportMeta } from '../src/checkers/zip-structure.js';

describe('checkReportMeta', () => {
  it('passes for valid report_meta', () => {
    const result = checkReportMeta({
      reportVersion: '1.1',
      reportSealVersion: '1.0',
      integrityLevel: 'full',
      reportRootHash: 'abc',
    });
    expect(result.ok).toBe(true);
  });

  it('skips when report_meta is null (legacy)', () => {
    const result = checkReportMeta(null);
    expect(result.skipped).toBe(true);
    expect(result.ok).toBe(true);
  });

  it('warns when reportVersion missing', () => {
    const result = checkReportMeta({ reportSealVersion: '1.0' });
    expect(result.warnings.some(w => w.includes('reportVersion'))).toBe(true);
  });

  it('warns when reportSealVersion missing', () => {
    const result = checkReportMeta({ reportVersion: '1.1' });
    expect(result.warnings.some(w => w.includes('reportSealVersion'))).toBe(true);
  });

  it('warns when integrityLevel=full but reportRootHash absent', () => {
    const result = checkReportMeta({ reportVersion: '1.1', integrityLevel: 'full' });
    expect(result.warnings.length).toBeGreaterThan(0);
  });

  it('tolerates legacy report with partial metadata', () => {
    const result = checkReportMeta({ reportVersion: '1.1', integrityLevel: 'legacy' });
    expect(result.ok).toBe(true);
  });
});
