import { describe, it, expect } from 'vitest';
import { generateKeyPairSync, createSign } from 'node:crypto';
import { checkSignatureVerification } from '../src/checkers/signature-verifier.js';
import { canonicalJson } from '../src/canonical.js';
import type { SealJson } from '../src/types.js';

// Fresh test keypair — NOT the production key
const { privateKey: TEST_PRIVATE_KEY, publicKey: TEST_PUBLIC_KEY } = generateKeyPairSync('ec', {
  namedCurve: 'P-256',
  publicKeyEncoding: { type: 'spki', format: 'pem' },
  privateKeyEncoding: { type: 'pkcs8', format: 'pem' },
});

const { publicKey: OTHER_PUBLIC_KEY } = generateKeyPairSync('ec', {
  namedCurve: 'P-256',
  publicKeyEncoding: { type: 'spki', format: 'pem' },
  privateKeyEncoding: { type: 'pkcs8', format: 'pem' },
});

function buildRootPayload(overrides: Partial<Record<string, unknown>> = {}) {
  return {
    projectId: 'proj-123',
    companyId: 'test-company',
    sealedAt: '2026-03-17T10:00:00.000Z',
    eventsCount: 3,
    photosCount: 0,
    techniciansCount: 1,
    timelineHash: 'abc123timeline',
    photosBundleHash: 'def456photos',
    sealVersion: '1.0',
    ...overrides,
  };
}

function makeSignedSeal(payloadOverrides: Partial<Record<string, unknown>> = {}): SealJson {
  const payload = buildRootPayload(payloadOverrides);
  const sign = createSign('SHA256');
  sign.update(canonicalJson(payload), 'utf8');
  const signature = sign.sign(TEST_PRIVATE_KEY, 'hex');

  return {
    version: '2.0',
    algorithm: 'ES256',
    canonicalizationMethod: 'canonical-json-v1',
    signedAt: '2026-03-17T10:00:00.000Z',
    issuer: 'GeoTapp Flow',
    issuerType: 'platform',
    keyId: 'test-key-v1',
    signedRootHash: 'ignored-in-tests',
    signature,
    companyId: 'test-company',
    reportId: 'rpt_test',
    projectId: 'proj-123',
    eventsCount: 3,
    photosCount: 0,
    techniciansCount: 1,
    timelineHash: 'abc123timeline',
    photosBundleHash: 'def456photos',
    sealVersion: '1.0',
  };
}

describe('checkSignatureVerification', () => {
  it('returns ok:true skipped when sealJson is null (legacy report)', () => {
    const result = checkSignatureVerification(null, TEST_PUBLIC_KEY);
    expect(result.ok).toBe(true);
    expect(result.skipped).toBe(true);
    expect(result.details?.signatureStatus).toBe('absent');
  });

  it('returns ok:true skipped with warning when signature field is absent (hash-only seal)', () => {
    const seal: SealJson = {
      version: '2.0', algorithm: 'ES256', canonicalizationMethod: 'canonical-json-v1',
      signedAt: '2026-03-17T10:00:00.000Z', issuer: 'GeoTapp Flow', issuerType: 'platform',
      keyId: 'test-key-v1', signedRootHash: '', companyId: 'c1', reportId: 'r1', projectId: 'p1',
    };
    const result = checkSignatureVerification(seal, TEST_PUBLIC_KEY);
    expect(result.ok).toBe(true);
    expect(result.skipped).toBe(true);
    expect(result.warnings.length).toBeGreaterThan(0);
    expect(result.details?.signatureStatus).toBe('absent');
  });

  it('returns ok:true for a valid ECDSA signature', () => {
    const seal = makeSignedSeal();
    const result = checkSignatureVerification(seal, TEST_PUBLIC_KEY);
    expect(result.ok).toBe(true);
    expect(result.skipped).toBeUndefined();
    expect(result.details?.signatureStatus).toBe('verified');
    expect(result.details?.algorithm).toBe('ES256');
    expect(result.details?.keyId).toBe('test-key-v1');
    expect(result.details?.issuer).toBe('GeoTapp Flow');
  });

  it('returns ok:false for a tampered signature', () => {
    const seal = { ...makeSignedSeal(), signature: 'deadbeef'.repeat(8) };
    const result = checkSignatureVerification(seal, TEST_PUBLIC_KEY);
    expect(result.ok).toBe(false);
    expect(result.details?.signatureStatus).toBe('invalid');
    expect(result.errors.length).toBeGreaterThan(0);
  });

  it('returns ok:false when verified with a different public key', () => {
    const seal = makeSignedSeal();
    const result = checkSignatureVerification(seal, OTHER_PUBLIC_KEY);
    expect(result.ok).toBe(false);
    expect(result.details?.signatureStatus).toBe('invalid');
  });

  it('returns ok:false when payload fields in seal have been tampered', () => {
    const seal = makeSignedSeal(); // signed with eventsCount: 3
    const tamperedSeal = { ...seal, eventsCount: 99 }; // payload mismatch
    const result = checkSignatureVerification(tamperedSeal, TEST_PUBLIC_KEY);
    expect(result.ok).toBe(false);
  });

  it('returns ok:false with empty public key string', () => {
    const seal = makeSignedSeal();
    const result = checkSignatureVerification(seal, '');
    expect(result.ok).toBe(false);
  });
});
