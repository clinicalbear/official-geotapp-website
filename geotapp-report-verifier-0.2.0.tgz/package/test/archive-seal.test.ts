import { describe, it, expect } from 'vitest';
import { checkArchiveSeal } from '../src/checkers/archive-seal.js';
import { buildContext } from '../src/build-context.js';
import { buildValidArtifact } from './fixtures/factory.js';

describe('checkArchiveSeal', () => {
  it('skips when no archive seal present', () => {
    const ctx = buildContext(buildValidArtifact({ eventsCount: 2 }));
    const result = checkArchiveSeal(ctx);
    expect(result.skipped).toBe(true);
    expect(result.ok).toBe(true);
  });

  it('passes when archive seal hashes match metadata', () => {
    const artifact = buildValidArtifact({ eventsCount: 2 });
    const meta = artifact.reportMeta!;
    // Build a seal that matches
    meta.archiveSeal = {
      sealed: true,
      projectRootHash: 'root-hash-abc',
      timelineHash: meta.timelineHash!,
      photosBundleHash: meta.photosBundleHash!,
    };
    meta.archiveProjectRootHash = 'root-hash-abc';
    const ctx = buildContext(artifact);
    expect(checkArchiveSeal(ctx).ok).toBe(true);
  });

  it('errors when seal timelineHash differs from metadata', () => {
    const artifact = buildValidArtifact({ eventsCount: 2 });
    const meta = artifact.reportMeta!;
    meta.archiveSeal = {
      sealed: true,
      projectRootHash: 'root-hash-abc',
      timelineHash: 'wrong-timeline-hash',
      photosBundleHash: meta.photosBundleHash!,
    };
    meta.archiveProjectRootHash = 'root-hash-abc';
    const ctx = buildContext(artifact);
    const result = checkArchiveSeal(ctx);
    expect(result.ok).toBe(false);
    expect(result.errors.some(e => e.includes('timelineHash'))).toBe(true);
  });
});
