import { describe, it, expect } from 'vitest';
import { checkTimelineHash } from '../src/checkers/timeline-hash.js';
import { buildContext } from '../src/build-context.js';
import { buildValidArtifact } from './fixtures/factory.js';

describe('checkTimelineHash', () => {
  it('passes for a valid 3-event report', () => {
    const ctx = buildContext(buildValidArtifact({ eventsCount: 3 }));
    expect(checkTimelineHash(ctx).ok).toBe(true);
  });

  it('passes for empty event list (hash of empty chain)', () => {
    const ctx = buildContext(buildValidArtifact({ eventsCount: 0 }));
    expect(checkTimelineHash(ctx).ok).toBe(true);
  });

  it('skips when no expected hash available (legacy)', () => {
    const artifact = buildValidArtifact({ eventsCount: 2 });
    artifact.historyJson.timelineHash = undefined;
    (artifact.reportMeta as any).timelineHash = undefined;
    const ctx = buildContext(artifact);
    const result = checkTimelineHash(ctx);
    expect(result.skipped).toBe(true);
    expect(result.ok).toBe(true);
  });

  it('fails when timelineHash is wrong', () => {
    const artifact = buildValidArtifact({ eventsCount: 2 });
    (artifact.reportMeta as any).timelineHash = 'wrong-hash';
    const ctx = buildContext(artifact);
    expect(checkTimelineHash(ctx).ok).toBe(false);
  });

  it('is deterministic across repeated calls', () => {
    const artifact = buildValidArtifact({ eventsCount: 5 });
    const ctx = buildContext(artifact);
    const r1 = checkTimelineHash(ctx);
    const r2 = checkTimelineHash(ctx);
    expect(r1.ok).toBe(r2.ok);
    expect(r1.details?.['computed']).toBe(r2.details?.['computed']);
  });
});
