import { describe, it, expect } from 'vitest';
import { checkPhotoFiles } from '../src/checkers/photo-files.js';
import { buildContext } from '../src/build-context.js';
import { buildValidArtifact } from './fixtures/factory.js';
import { sha256HexBytes } from '../src/canonical.js';

describe('checkPhotoFiles', () => {
  it('passes when no photos expected', () => {
    const ctx = buildContext(buildValidArtifact({ eventsCount: 2 }));
    expect(checkPhotoFiles(ctx).ok).toBe(true);
  });

  it('warns when photo is missing and metadata says missingFile:true', () => {
    const artifact = buildValidArtifact({ eventsCount: 0 });
    // Inject a photo entry with missingFile:true
    artifact.historyJson.events.push({
      eventId: 'proof-1', timestamp: '2026-01-01T10:00:00.000Z',
      type: 'proof', user: 'u', gps: { latitude: null, longitude: null },
      description: '', previousEventHash: '', eventHash: 'x',
      photosMeta: [{ photoId: 'p1', missingFile: true, fileSha256: '' }],
    } as any);
    const ctx = buildContext(artifact);
    const result = checkPhotoFiles(ctx);
    expect(result.ok).toBe(true);
    expect(result.warnings.some(w => w.includes('missing'))).toBe(true);
  });

  it('errors when photo file bytes do not match fileSha256', () => {
    const artifact = buildValidArtifact({ eventsCount: 0 });
    const fakeBytes = new Uint8Array([1, 2, 3]);
    artifact.historyJson.events.push({
      eventId: 'proof-1', timestamp: '2026-01-01T10:00:00.000Z',
      type: 'proof', user: 'u', gps: { latitude: null, longitude: null },
      description: '', previousEventHash: '', eventHash: 'x',
      photosMeta: [{ photoId: 'p1', fileSha256: 'deadbeef', missingFile: false }],
    } as any);
    artifact.photoFiles.set('proof_p1.jpg', fakeBytes);
    const ctx = buildContext(artifact);
    const result = checkPhotoFiles(ctx);
    expect(result.ok).toBe(false);
    expect(result.errors.some(e => e.includes('hash mismatch'))).toBe(true);
  });

  it('passes when photo file bytes match fileSha256', () => {
    const artifact = buildValidArtifact({ eventsCount: 0 });
    const fileBytes = new Uint8Array([10, 20, 30, 40]);
    const fileSha256 = sha256HexBytes(fileBytes);
    artifact.historyJson.events.push({
      eventId: 'proof-1', timestamp: '2026-01-01T10:00:00.000Z',
      type: 'proof', user: 'u', gps: { latitude: null, longitude: null },
      description: '', previousEventHash: '', eventHash: 'x',
      photosMeta: [{ photoId: 'p1', fileSha256, missingFile: false }],
    } as any);
    artifact.photoFiles.set('proof_p1.jpg', fileBytes);
    const ctx = buildContext(artifact);
    expect(checkPhotoFiles(ctx).ok).toBe(true);
  });
});
