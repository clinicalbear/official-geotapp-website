import { describe, it, expect } from 'vitest';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { verifyZipFile } from '../src/index.js';
import { verifyArtifact } from '../src/verify.js';
import {
  buildValidArtifact,
  buildLegacyArtifact,
  tamperEventHash,
  tamperRootHash,
  buildSealedArtifact,
  TEST_KEY_PAIR,
} from './fixtures/factory.js';
import { checkSignatureVerification } from '../src/checkers/signature-verifier.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const fixture = (name: string) => path.join(__dirname, 'fixtures', name);

describe('verifyArtifact — programmatic', () => {
  it('valid artifact → status valid', () => {
    const result = verifyArtifact(buildValidArtifact({ eventsCount: 3 }));
    expect(result.status).toBe('valid');
    expect(result.checks.eventHashChain.ok).toBe(true);
    expect(result.checks.reportRootHash.ok).toBe(true);
  });

  it('legacy artifact → integrityLevel legacy', () => {
    const result = verifyArtifact(buildLegacyArtifact());
    expect(result.integrityLevel).toBe('legacy');
    expect(result.status).not.toBe('invalid');
  });

  it('tampered event hash → status invalid', () => {
    const artifact = tamperEventHash(buildValidArtifact({ eventsCount: 3 }), 1);
    const result = verifyArtifact(artifact);
    expect(result.status).toBe('invalid');
    expect(result.checks.eventHashChain.ok).toBe(false);
  });

  it('tampered root hash → status invalid', () => {
    const artifact = tamperRootHash(buildValidArtifact({ eventsCount: 3 }));
    const result = verifyArtifact(artifact);
    expect(result.status).toBe('invalid');
    expect(result.checks.reportRootHash.ok).toBe(false);
  });

  it('zero events → valid', () => {
    const result = verifyArtifact(buildValidArtifact({ eventsCount: 0 }));
    expect(result.status).toBe('valid');
  });
});

describe('verifyZipFile — committed fixtures', () => {
  it('sample-valid-full.zip → valid', async () => {
    const result = await verifyZipFile(fixture('sample-valid-full.zip'));
    expect(result.status).toBe('valid');
    expect(result.checks.eventHashChain.ok).toBe(true);
  });

  it('sample-legacy.zip → legacy integrityLevel', async () => {
    const result = await verifyZipFile(fixture('sample-legacy.zip'));
    expect(result.integrityLevel).toBe('legacy');
  });

  it('sample-partial.zip → not invalid', async () => {
    const result = await verifyZipFile(fixture('sample-partial.zip'));
    expect(result.status).not.toBe('invalid');
  });
});

// ─── v2.0 sealed report tests ────────────────────────────────────────────────

describe('v2 sealed reports — signature verification', () => {
  it('signatureStatus is verified when seal is signed with the correct key', () => {
    // verifyArtifact uses the bundled production key (geotapp-seal-2026-v1.pem).
    // buildSealedArtifact signs with TEST_KEY_PAIR but uses keyId 'geotapp-seal-2026-v1'.
    // So we test checkSignatureVerification directly with the test public key.
    const artifact = buildSealedArtifact({ eventsCount: 3 });
    const result = checkSignatureVerification(artifact.sealJson, TEST_KEY_PAIR.publicKey);
    expect(result.ok).toBe(true);
    expect(result.details?.signatureStatus).toBe('verified');
    expect(result.details?.issuer).toBe('GeoTapp Flow');
  });

  it('signatureStatus is invalid when signature is tampered', () => {
    const artifact = buildSealedArtifact({ eventsCount: 2 });
    const tamperedSeal = { ...artifact.sealJson!, signature: 'badc0de0'.repeat(9) };
    const result = checkSignatureVerification(tamperedSeal, TEST_KEY_PAIR.publicKey);
    expect(result.ok).toBe(false);
    expect(result.details?.signatureStatus).toBe('invalid');
    expect(result.errors.length).toBeGreaterThan(0);
  });

  it('signatureStatus is invalid when payload field (eventsCount) is tampered', () => {
    const artifact = buildSealedArtifact({ eventsCount: 3 });
    // Tamper the eventsCount in sealJson — payload reconstructed by verifier will differ
    const tamperedSeal = { ...artifact.sealJson!, eventsCount: 999 };
    const result = checkSignatureVerification(tamperedSeal, TEST_KEY_PAIR.publicKey);
    expect(result.ok).toBe(false);
  });

  it('signatureStatus is absent (skipped) for a hash-only seal without signature', () => {
    const artifact = buildSealedArtifact({ eventsCount: 2 });
    const { signature: _omitted, ...sealWithoutSig } = artifact.sealJson!;
    const result = checkSignatureVerification(sealWithoutSig as any, TEST_KEY_PAIR.publicKey);
    expect(result.ok).toBe(true);
    expect(result.skipped).toBe(true);
    expect(result.details?.signatureStatus).toBe('absent');
  });

  it('sealStatus is absent and signatureStatus is absent for legacy artifact', () => {
    const artifact = buildLegacyArtifact();
    const result = verifyArtifact(artifact);
    expect(result.sealStatus).toBe('absent');
    expect(result.signatureStatus).toBe('absent');
  });

  it('sealStatus is sealed for a v2 artifact with signature', () => {
    const artifact = buildSealedArtifact({ eventsCount: 2 });
    const result = verifyArtifact(artifact);
    expect(result.sealStatus).toBe('sealed');
  });

  it('companyIdentity fields are populated from sealJson', () => {
    const artifact = buildSealedArtifact({ eventsCount: 1 });
    const result = verifyArtifact(artifact);
    expect(result.companyIdentity.companyId).toBe('test-company');
    expect(result.companyIdentity.reportId).toBe('rpt_test-company_test-proj');
  });

  it('verificationMode is always local for verifyArtifact', () => {
    const artifact = buildSealedArtifact();
    expect(verifyArtifact(artifact).verificationMode).toBe('local');
  });
});
