import { describe, it, expect } from 'vitest';
import { buildContext } from '../src/build-context.js';
import type { ReportArtifact } from '../src/types.js';

function makeArtifact(overrides?: Partial<ReportArtifact>): ReportArtifact {
  const historyJson = {
    reportVersion: '1.1',
    generatedAt: '2026-01-01T00:00:00.000Z',
    timelineHash: 'tl-hash-from-history',
    photosBundleHash: 'pb-hash-from-history',
    events: [
      {
        eventId: 'b', timestamp: '2026-01-15T10:00:00.000Z',
        type: 'proof', user: 'u1', gps: { latitude: null, longitude: null },
        description: '', previousEventHash: 'first-hash', eventHash: 'b-hash',
      },
      {
        eventId: 'a', timestamp: '2026-01-15T09:00:00.000Z',
        type: 'proof', user: 'u1', gps: { latitude: null, longitude: null },
        description: '', previousEventHash: '', eventHash: 'a-hash',
      },
    ],
  };
  const historyJsonBytes = new TextEncoder().encode(JSON.stringify(historyJson));
  return {
    historyJson,
    reportMeta: {
      reportVersion: '1.1',
      reportSealVersion: '1.0',
      eventsCount: 2,
      photosCount: 0,
      techniciansCount: 1,
      timelineHash: 'tl-hash-from-meta',
      photosBundleHash: 'pb-hash-from-meta',
    },
    historyJsonBytes,
    photoFiles: new Map(),
    ...overrides,
  };
}

describe('buildContext', () => {
  it('sorts events by timestamp ascending', () => {
    const ctx = buildContext(makeArtifact());
    expect(ctx.events[0].eventId).toBe('a');
    expect(ctx.events[1].eventId).toBe('b');
  });

  it('computes historyHash from raw bytes', () => {
    const artifact = makeArtifact();
    const ctx = buildContext(artifact);
    expect(ctx.historyHash).toHaveLength(64);
    expect(ctx.historyHash).toMatch(/^[0-9a-f]+$/);
  });

  it('prefers report_meta timelineHash over history.json', () => {
    const ctx = buildContext(makeArtifact());
    expect(ctx.timelineHashExpected).toBe('tl-hash-from-meta');
  });

  it('falls back to history.json timelineHash when report_meta absent', () => {
    const ctx = buildContext(makeArtifact({ reportMeta: null }));
    expect(ctx.timelineHashExpected).toBe('tl-hash-from-history');
  });

  it('reads summary counts from report_meta', () => {
    const ctx = buildContext(makeArtifact());
    expect(ctx.summary.eventsCount).toBe(2);
    expect(ctx.summary.photosCount).toBe(0);
    expect(ctx.summary.techniciansCount).toBe(1);
  });

  it('builds timeline events with reduced field set', () => {
    const ctx = buildContext(makeArtifact());
    const te = ctx.timelineEvents[0];
    expect(te).toHaveProperty('eventId');
    expect(te).toHaveProperty('timestamp');
    expect(te).toHaveProperty('type');
    expect(te).toHaveProperty('user');
    expect(te).toHaveProperty('gps');
    expect(te).toHaveProperty('description');
    // must NOT have chain fields
    expect(te).not.toHaveProperty('previousEventHash');
    expect(te).not.toHaveProperty('eventHash');
  });

  it('extracts photos from proof events with photosMeta', () => {
    const artifact = makeArtifact();
    (artifact.historyJson.events[0] as any).photosMeta = [
      { photoId: 'p1', photoUrl: 'https://example.com/p1.jpg', fileSha256: 'ABCD', missingFile: false },
      { photoId: 'p2', photoUrl: 'https://example.com/p2.jpg', fileSha256: '', missingFile: true },
    ];
    const ctx = buildContext(artifact);
    expect(ctx.photos).toHaveLength(2);
    expect(ctx.photos[0].photoOrder).toBe(1);
    expect(ctx.photos[1].photoOrder).toBe(2);
    expect(ctx.photos[0].fileSha256).toBe('abcd'); // lowercased
    expect(ctx.photos[0].sourceUrl).toBe('https://example.com/p1.jpg');
    expect(ctx.photos[1].missingFile).toBe(true);
  });

  it('does not include photos from non-proof events', () => {
    const artifact = makeArtifact();
    (artifact.historyJson.events[0] as any).type = 'sessionStart';
    (artifact.historyJson.events[0] as any).photosMeta = [
      { photoId: 'p1', photoUrl: 'u', fileSha256: 'abc' },
    ];
    const ctx = buildContext(artifact);
    expect(ctx.photos).toHaveLength(0);
  });
});
