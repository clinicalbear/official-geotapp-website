/**
 * GeoTapp public keys for seal verification, keyed by keyId.
 *
 * Keys are inlined as string literals to support Cloudflare Workers (no fs access).
 *
 * To rotate keys:
 *   1. Generate new keypair
 *   2. Add entry here: 'geotapp-seal-YYYY-v1' → PEM string literal
 *   3. Also save the .pem file alongside for reference
 *   4. Update SEAL_KEY_ID in geotapp-flow/functions/index.js
 *   5. Old keyId entries must remain for verification of existing reports
 */
export const GEOTAPP_PUBLIC_KEYS: Record<string, string> = {
  'geotapp-seal-2026-v1': `-----BEGIN PUBLIC KEY-----
MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAE5BKTkgTBtzLKQAlR679xsgPMbIQe
LNmrFIBX8cXgPYWilkbIuy0+s+8Kts7r20MPs8ZhOnJjE2AKpVTgykv45Q==
-----END PUBLIC KEY-----
`,
};

export function getPublicKeyForSeal(keyId: string | undefined): string | null {
  if (!keyId) return null;
  return GEOTAPP_PUBLIC_KEYS[keyId] ?? null;
}
