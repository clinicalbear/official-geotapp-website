import { Command } from 'commander';
import path from 'node:path';
import fs from 'node:fs';
import { readReportFromZip } from './reader/zip-reader.js';
import { readReportFromFolder } from './reader/folder-reader.js';
import { verifyArtifact } from './verify.js';
import type { VerificationResult, CheckResult } from './types.js';

const program = new Command();

program
  .name('geotapp-report-verify')
  .description('Offline integrity verifier for GeoTapp exported reports')
  .version('0.1.0')
  .argument('<path>', 'Path to report ZIP file or extracted folder')
  .option('--json', 'Output machine-readable JSON result')
  .option('--verbose', 'Show per-event and per-photo detail')
  .action(async (inputPath: string, opts: { json?: boolean; verbose?: boolean }) => {
    const resolved = path.resolve(inputPath);

    let artifact;
    try {
      const stat = fs.statSync(resolved);
      if (stat.isDirectory()) {
        artifact = await readReportFromFolder(resolved);
      } else {
        artifact = await readReportFromZip(resolved);
      }
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : String(err);
      if (opts.json) {
        process.stdout.write(JSON.stringify({ error: message }, null, 2) + '\n');
      } else {
        process.stderr.write(`ERROR: ${message}\n`);
      }
      process.exit(2);
    }

    const result = verifyArtifact(artifact);

    if (opts.json) {
      process.stdout.write(JSON.stringify(result, null, 2) + '\n');
    } else {
      printHuman(result, path.basename(resolved), opts.verbose ?? false);
    }

    process.exit(result.status === 'invalid' ? 1 : 0);
  });

program.parse();

function icon(check: CheckResult): string {
  if (check.skipped) return '–';
  return check.ok ? '✔' : '✘';
}

function printHuman(result: VerificationResult, filename: string, verbose: boolean): void {
  const statusLabel = `${result.status.toUpperCase()} (${result.integrityLevel.toUpperCase()})`;
  const bar = '─'.repeat(Math.max(statusLabel.length + filename.length + 2, 50));

  process.stdout.write(`\n${statusLabel}  ${filename}\n${bar}\n`);

  const c = result.checks;
  process.stdout.write(`${icon(c.zipStructure)}  zip structure        ${c.zipStructure.ok ? 'required files present' : c.zipStructure.errors[0]}\n`);
  process.stdout.write(`${icon(c.eventHashChain)}  event hash chain     ${c.eventHashChain.skipped ? 'skipped (legacy)' : c.eventHashChain.ok ? `${c.eventHashChain.details?.['verifiedCount']} events verified` : c.eventHashChain.errors[0]}\n`);
  process.stdout.write(`${icon(c.timelineHash)}  timeline hash        ${c.timelineHash.skipped ? 'skipped (legacy)' : c.timelineHash.ok ? 'OK' : c.timelineHash.errors[0]}\n`);
  process.stdout.write(`${icon(c.photosBundleHash)}  photos bundle hash   ${c.photosBundleHash.skipped ? 'skipped (legacy)' : c.photosBundleHash.ok ? 'OK' : c.photosBundleHash.errors[0]}\n`);
  process.stdout.write(`${icon(c.reportRootHash)}  report root hash     ${c.reportRootHash.skipped ? 'skipped (legacy)' : c.reportRootHash.ok ? 'OK' : c.reportRootHash.errors[0]}\n`);
  process.stdout.write(`${icon(c.photoFiles)}  photo files          ${c.photoFiles.ok ? `${c.photoFiles.details?.['matched'] ?? 0}/${result.summary.photosCount} matched` : c.photoFiles.errors[0]}\n`);
  process.stdout.write(`${icon(c.archiveSeal)}  archive seal         ${c.archiveSeal.skipped ? 'not present' : c.archiveSeal.ok ? 'OK' : c.archiveSeal.errors[0]}\n`);
  process.stdout.write(
    `${icon(c.signatureVerification)}  firma ECDSA          ${
      c.signatureVerification.skipped
        ? result.sealStatus === 'absent'
          ? 'assente (report legacy)'
          : 'sigillo non firmato (hash-only)'
        : c.signatureVerification.ok
          ? `verificata · keyId: ${String(c.signatureVerification.details?.['keyId'] ?? '')} · emittente: ${String(c.signatureVerification.details?.['issuer'] ?? '')}`
          : c.signatureVerification.errors[0] ?? 'errore sconosciuto'
    }\n`,
  );

  process.stdout.write(`\nreportVersion: ${result.reportVersion} | reportSealVersion: ${result.reportSealVersion}\n`);
  if (result.companyIdentity.companyId) {
    const nameDisplay = result.companyIdentity.companyName
      ? ` (${result.companyIdentity.companyName})`
      : '';
    process.stdout.write(`companyId: ${result.companyIdentity.companyId}${nameDisplay}\n`);
  }
  if (result.companyIdentity.reportId) {
    process.stdout.write(`reportId:  ${result.companyIdentity.reportId}\n`);
  }

  if (result.errors.length > 0) {
    process.stdout.write('\nErrors:\n');
    for (const e of result.errors) process.stdout.write(`  • ${e}\n`);
  }
  if (result.warnings.length > 0 && verbose) {
    process.stdout.write('\nWarnings:\n');
    for (const w of result.warnings) process.stdout.write(`  ⚠ ${w}\n`);
  }
  process.stdout.write('\n');
}
