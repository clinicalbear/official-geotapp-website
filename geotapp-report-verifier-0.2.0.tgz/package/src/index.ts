export { verifyArtifact } from './verify.js';
export { readReportFromZip, readReportFromZipBuffer } from './reader/zip-reader.js';
export { readReportFromFolder } from './reader/folder-reader.js';
export type {
  ReportArtifact,
  VerificationResult,
  CheckResult,
  VerificationContext,
} from './types.js';
import type { VerificationResult } from './types.js';

export const VERSION = '0.2.0';

// Convenience: verify a ZIP file path directly
export async function verifyZipFile(zipPath: string): Promise<VerificationResult> {
  const { readReportFromZip } = await import('./reader/zip-reader.js');
  const { verifyArtifact } = await import('./verify.js');
  return verifyArtifact(await readReportFromZip(zipPath));
}

export async function verifyFolder(folderPath: string): Promise<VerificationResult> {
  const { readReportFromFolder } = await import('./reader/folder-reader.js');
  const { verifyArtifact } = await import('./verify.js');
  return verifyArtifact(await readReportFromFolder(folderPath));
}
