import type { VerificationResult } from './types.js';

type Checks = VerificationResult['checks'];

export function classifyStatus(checks: Checks): 'valid' | 'degraded' | 'invalid' {
  const criticalFailed =
    !checks.eventHashChain.ok ||
    !checks.timelineHash.ok ||
    !checks.reportRootHash.ok ||
    (!checks.signatureVerification.ok && !checks.signatureVerification.skipped);

  if (criticalFailed) return 'invalid';

  const hasNonCriticalFailures =
    !checks.photoFiles.ok ||
    (!checks.archiveSeal.ok && !checks.archiveSeal.skipped) ||
    checks.eventHashChain.warnings.length > 0 ||
    checks.timelineHash.warnings.length > 0;

  return hasNonCriticalFailures ? 'degraded' : 'valid';
}

export function classifyIntegrityLevel(
  checks: Checks,
  storedLevel?: string
): 'full' | 'partial' | 'legacy' | 'invalid' {
  // Respect stored integrityLevel for legacy classification
  if (storedLevel === 'legacy') return 'legacy';

  if (!checks.eventHashChain.ok || !checks.reportRootHash.ok) return 'invalid';

  // Full: all hashes valid, archive seal present and matched, no photo file issues
  const sealOk = checks.archiveSeal.ok && !checks.archiveSeal.skipped;
  const photosOk = checks.photoFiles.ok;
  const signatureOk = checks.signatureVerification.ok && !checks.signatureVerification.skipped;

  if (sealOk && photosOk && checks.photosBundleHash.ok && !checks.photosBundleHash.skipped && signatureOk) {
    return 'full';
  }

  // Legacy: timelineHash or photosBundleHash were skipped (absent in metadata)
  if (checks.timelineHash.skipped || checks.photosBundleHash.skipped) return 'legacy';

  return 'partial';
}
