import type { VerificationContext, CheckResult } from '../types.js';
import { canonicalJson, sha256Hex } from '../canonical.js';

export function checkEventHashChain(ctx: VerificationContext): CheckResult {
  const errors: string[] = [];
  const warnings: string[] = [];
  let verifiedCount = 0;
  let previousHash = '';

  // Legacy reports have no stored hashes — skip chain verification, warn only
  const isLegacy = !ctx.artifact.historyJson.reportVersion;
  const hasEvents = ctx.events.length > 0;
  const allHashesEmpty = hasEvents && ctx.events.every(e => !e.storedEventHash);
  if (isLegacy || allHashesEmpty) {
    return {
      ok: true,
      skipped: true,
      warnings: ['Event hash chain not present (legacy report) — skipping chain verification'],
      errors: [],
      details: { totalEvents: ctx.events.length, verifiedCount: 0, failedCount: 0 },
    };
  }

  for (const event of ctx.events) {
    const payload = {
      eventId: event.eventId,
      timestamp: event.timestamp,
      type: event.type,
      user: event.user,
      gps: event.gps,
      description: event.description,
      previousEventHash: previousHash,
    };

    const computed = sha256Hex(canonicalJson(payload));

    // Check previousEventHash linkage
    if (event.storedPreviousHash !== previousHash) {
      errors.push(
        `previousEventHash mismatch at event ${event.originalIndex} (${event.eventId}): ` +
        `stored="${event.storedPreviousHash.slice(0, 8)}…" expected="${previousHash.slice(0, 8)}…"`
      );
    }

    // Check eventHash
    if (event.storedEventHash !== computed) {
      errors.push(
        `eventHash mismatch at event ${event.originalIndex} (${event.eventId}): ` +
        `stored="${event.storedEventHash.slice(0, 8)}…" computed="${computed.slice(0, 8)}…"`
      );
    } else {
      verifiedCount++;
    }

    previousHash = computed;
  }

  return {
    ok: errors.length === 0,
    errors,
    warnings,
    details: {
      totalEvents: ctx.events.length,
      verifiedCount,
      failedCount: errors.length,
    },
  };
}
