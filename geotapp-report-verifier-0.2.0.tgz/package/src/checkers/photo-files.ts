import type { VerificationContext, CheckResult } from '../types.js';
import { sha256HexBytes } from '../canonical.js';

export function checkPhotoFiles(ctx: VerificationContext): CheckResult {
  const errors: string[] = [];
  const warnings: string[] = [];
  let matched = 0;
  let missing = 0;

  for (const photo of ctx.photos) {
    if (photo.missingFile) {
      warnings.push(`Photo ${photo.photoId} (proof ${photo.proofId}) marked as missing in metadata`);
      missing++;
      continue;
    }

    if (!photo.fileSha256) continue;   // no hash to check against

    // Try to find the file by photoId (common naming pattern: proof_<photoId>.*)
    const matchingEntry = [...ctx.artifact.photoFiles.entries()].find(
      ([name]) => name.includes(photo.photoId)
    );

    if (!matchingEntry) {
      errors.push(`Photo file not found in ZIP for photoId=${photo.photoId} (no missingFile flag)`);
      missing++;
      continue;
    }

    const [, bytes] = matchingEntry;
    const computed = sha256HexBytes(bytes);
    if (computed !== photo.fileSha256) {
      errors.push(
        `Photo hash mismatch for photoId=${photo.photoId}: ` +
        `computed="${computed.slice(0, 8)}…" expected="${photo.fileSha256.slice(0, 8)}…"`
      );
    } else {
      matched++;
    }
  }

  return {
    ok: errors.length === 0,
    errors,
    warnings,
    details: { matched, missing, total: ctx.photos.length },
  };
}
