import type { VerificationContext, CheckResult } from '../types.js';

export function checkArchiveSeal(ctx: VerificationContext): CheckResult {
  const { reportMeta } = ctx.artifact;

  if (!reportMeta?.archiveSeal) {
    return {
      ok: true,
      skipped: true,
      warnings: ['Archive seal not present — report cannot be matched to sealed project state'],
      errors: [],
      details: { archiveSealPresent: false },
    };
  }

  const seal = reportMeta.archiveSeal;
  const errors: string[] = [];

  if (seal.timelineHash !== reportMeta.timelineHash) {
    errors.push(
      `archiveSeal.timelineHash mismatch: seal="${String(seal.timelineHash).slice(0, 8)}…" meta="${String(reportMeta.timelineHash).slice(0, 8)}…"`
    );
  }

  if (seal.photosBundleHash !== reportMeta.photosBundleHash) {
    errors.push(
      `archiveSeal.photosBundleHash mismatch: seal="${String(seal.photosBundleHash).slice(0, 8)}…" meta="${String(reportMeta.photosBundleHash).slice(0, 8)}…"`
    );
  }

  if (seal.projectRootHash !== reportMeta.archiveProjectRootHash) {
    errors.push(
      `archiveSeal.projectRootHash mismatch: seal="${String(seal.projectRootHash).slice(0, 8)}…" meta="${String(reportMeta.archiveProjectRootHash).slice(0, 8)}…"`
    );
  }

  return {
    ok: errors.length === 0,
    errors,
    warnings: [],
    details: {
      archiveSealPresent: true,
      archiveSealMatched: errors.length === 0,
    },
  };
}
