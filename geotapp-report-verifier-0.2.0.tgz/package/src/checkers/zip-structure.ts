import type { ReportArtifact, CheckResult, HistoryJson, ReportMeta } from '../types.js';

export function checkZipStructure(artifact: ReportArtifact): CheckResult {
  const errors: string[] = [];
  const warnings: string[] = [];

  // history.json is always required (reader already throws if absent; this
  // checks consistency of the parsed result)
  if (!artifact.historyJsonBytes || artifact.historyJsonBytes.length === 0) {
    errors.push('data/history.json is empty or unreadable');
  }

  // report_meta.json required for modern reports
  const isLegacy = !artifact.historyJson.reportVersion;
  if (!isLegacy && artifact.reportMeta === null) {
    errors.push('metadata/report_meta.json missing (required for modern reports with reportVersion)');
  }

  // report.html is informational only — never checked for integrity
  // photos/ absence is handled by photoFiles checker

  return { ok: errors.length === 0, errors, warnings };
}

export function checkHistoryJson(historyJson: HistoryJson): CheckResult {
  const errors: string[] = [];
  const warnings: string[] = [];

  if (!Array.isArray((historyJson as any).events)) {
    errors.push('history.json missing required field: events (must be an array)');
    return { ok: false, errors, warnings };
  }

  if (!historyJson.reportVersion) {
    warnings.push('history.json has no reportVersion — treating as legacy report');
  }

  return { ok: true, errors, warnings };
}

export function checkReportMeta(reportMeta: ReportMeta | null): CheckResult {
  if (reportMeta === null) {
    return { ok: true, skipped: true, warnings: [], errors: [] };
  }

  const warnings: string[] = [];
  const errors: string[] = [];

  if (!reportMeta.reportVersion) {
    warnings.push('report_meta.json missing field: reportVersion');
  }
  if (!reportMeta.reportSealVersion) {
    warnings.push('report_meta.json missing field: reportSealVersion');
  }

  // Consistency: if integrityLevel is 'full', reportRootHash should be present
  if (reportMeta.integrityLevel === 'full' && !reportMeta.reportRootHash) {
    warnings.push('integrityLevel is "full" but reportRootHash is absent — inconsistent metadata');
  }

  return { ok: errors.length === 0, errors, warnings };
}
