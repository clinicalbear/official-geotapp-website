import type { VerificationContext, CheckResult } from '../types.js';
import { canonicalJson, sha256Hex } from '../canonical.js';
import { computeTimelineHash } from './timeline-hash.js';
import { computePhotosBundleHash } from './photos-bundle-hash.js';

export function checkReportRootHash(ctx: VerificationContext): CheckResult {
  const { reportMeta } = ctx.artifact;

  if (!reportMeta) {
    return { ok: true, skipped: true, warnings: ['No report_meta.json — skipping root hash check'], errors: [] };
  }
  if (!reportMeta.reportRootHash) {
    return { ok: true, skipped: true, warnings: ['reportRootHash absent in metadata (legacy report)'], errors: [] };
  }

  // Recompute all component hashes
  const timelineHash = computeTimelineHash(ctx.timelineEvents);
  const photosBundleHash = computePhotosBundleHash(ctx.photos);
  const archiveProjectRootHash = reportMeta.archiveProjectRootHash ?? null;

  const payload = {
    historyHash: ctx.historyHash,
    summary: ctx.artifact.historyJson.summary ?? {},
    eventsCount: ctx.summary.eventsCount,
    photosCount: ctx.summary.photosCount,
    techniciansCount: ctx.summary.techniciansCount,
    timelineHash,
    photosBundleHash,
    archiveProjectRootHash,
    reportVersion: reportMeta.reportVersion ?? reportMeta.version ?? '',
    reportSealVersion: reportMeta.reportSealVersion ?? '',
  };

  const computed = sha256Hex(canonicalJson(payload));

  if (computed !== reportMeta.reportRootHash) {
    return {
      ok: false,
      errors: [
        `reportRootHash mismatch: computed="${computed.slice(0, 16)}…" stored="${reportMeta.reportRootHash.slice(0, 16)}…"`,
      ],
      warnings: [],
      details: { computed, stored: reportMeta.reportRootHash },
    };
  }

  return { ok: true, errors: [], warnings: [], details: { computed } };
}
