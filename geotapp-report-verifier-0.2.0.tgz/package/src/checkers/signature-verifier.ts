import { createVerify } from 'node:crypto';
import { canonicalJson } from '../canonical.js';
import type { SealJson, CheckResult } from '../types.js';

/**
 * Reconstructs the rootPayload that was signed by the Cloud Function.
 *
 * MUST stay byte-for-byte identical to the rootPayload built in:
 *   geotapp-flow/functions/index.js → computeArchiveSealForProject()
 *
 * Signed fields (sorted by canonicalJson's key-sorting):
 *   companyId, eventsCount, photosBundleHash, photosCount,
 *   projectId, sealVersion, sealedAt, techniciansCount, timelineHash
 *
 * The field name in the Cloud Function is `sealedAt` (from the rootPayload),
 * which is stored in seal.json as `signedAt`.
 *
 * DO NOT add or remove fields without updating computeArchiveSealForProject first.
 */
function extractSignedPayload(seal: SealJson): Record<string, unknown> {
  return {
    projectId: seal.projectId,
    companyId: seal.companyId,
    sealedAt: seal.signedAt,          // seal.json stores this as signedAt
    eventsCount: seal.eventsCount ?? 0,
    photosCount: seal.photosCount ?? 0,
    techniciansCount: seal.techniciansCount ?? 0,
    timelineHash: seal.timelineHash ?? '',
    photosBundleHash: seal.photosBundleHash ?? '',
    sealVersion: seal.sealVersion ?? '1.0',
  };
}

export function checkSignatureVerification(
  sealJson: SealJson | null,
  publicKeyPem: string,
): CheckResult {
  // Legacy / pre-v2 reports have no seal.json at all
  if (sealJson === null) {
    return {
      ok: true,
      skipped: true,
      warnings: [],
      errors: [],
      details: { signatureStatus: 'absent' },
    };
  }

  // Seal present but unsigned (hash-only seal — key not configured at seal time)
  if (!sealJson.signature) {
    return {
      ok: true,
      skipped: true,
      warnings: [
        'Firma assente nel sigillo: report sigillato senza firma crittografica (pre-v2 o chiave non configurata)',
      ],
      errors: [],
      details: { signatureStatus: 'absent' },
    };
  }

  if (!publicKeyPem) {
    return {
      ok: false,
      warnings: [],
      errors: ['Chiave pubblica non disponibile per la verifica della firma'],
      details: { signatureStatus: 'invalid' },
    };
  }

  try {
    const payload = extractSignedPayload(sealJson);
    const verify = createVerify('SHA256');
    verify.update(canonicalJson(payload), 'utf8');
    verify.end();
    const valid = verify.verify(publicKeyPem, sealJson.signature, 'hex');

    if (!valid) {
      return {
        ok: false,
        warnings: [],
        errors: [
          'Firma ECDSA non valida: il sigillo potrebbe essere stato alterato dopo la generazione',
        ],
        details: { signatureStatus: 'invalid', keyId: sealJson.keyId },
      };
    }

    return {
      ok: true,
      warnings: [],
      errors: [],
      details: {
        signatureStatus: 'verified',
        algorithm: sealJson.algorithm,
        keyId: sealJson.keyId,
        issuer: sealJson.issuer,
        signedAt: sealJson.signedAt,
      },
    };
  } catch (err) {
    return {
      ok: false,
      warnings: [],
      errors: [
        `Errore durante la verifica della firma: ${err instanceof Error ? err.message : String(err)}`,
      ],
      details: { signatureStatus: 'invalid' },
    };
  }
}
