import type { VerificationContext, CheckResult, NormalizedTimelineEvent } from '../types.js';
import { canonicalJson, sha256Hex } from '../canonical.js';

export function checkTimelineHash(ctx: VerificationContext): CheckResult {
  if (ctx.timelineHashExpected === null || ctx.timelineHashExpected === undefined) {
    return {
      ok: true,
      skipped: true,
      warnings: ['timelineHash not present in metadata — skipping (legacy report)'],
      errors: [],
    };
  }

  const computed = computeTimelineHash(ctx.timelineEvents);

  if (computed !== ctx.timelineHashExpected) {
    return {
      ok: false,
      errors: [
        `timelineHash mismatch: computed="${computed.slice(0, 16)}…" expected="${ctx.timelineHashExpected.slice(0, 16)}…"`,
      ],
      warnings: [],
      details: { computed, expected: ctx.timelineHashExpected },
    };
  }

  return {
    ok: true,
    errors: [],
    warnings: [],
    details: { computed },
  };
}

export function computeTimelineHash(events: NormalizedTimelineEvent[]): string {
  let previousHash = '';
  for (const e of events) {
    const payload = {
      eventId: e.eventId,
      timestamp: e.timestamp,
      type: e.type,
      user: e.user,
      gps: e.gps,
      description: e.description,
      previousEventHash: previousHash,
    };
    previousHash = sha256Hex(canonicalJson(payload));
  }
  return previousHash;   // empty string for zero events
}
