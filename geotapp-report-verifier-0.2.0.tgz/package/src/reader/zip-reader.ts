import JSZip from 'jszip';
import fs from 'node:fs/promises';
import type { ReportArtifact, HistoryJson, ReportMeta, SealJson } from '../types.js';

export async function readReportFromZip(zipPath: string): Promise<ReportArtifact> {
  const buffer = await fs.readFile(zipPath);
  const zip = await JSZip.loadAsync(buffer);
  return readReportFromZipObject(zip);
}

export async function readReportFromZipBuffer(buffer: Uint8Array): Promise<ReportArtifact> {
  const zip = await JSZip.loadAsync(buffer);
  return readReportFromZipObject(zip);
}

async function readReportFromZipObject(zip: JSZip): Promise<ReportArtifact> {
  // history.json is required
  const historyFile = zip.file('data/history.json');
  if (!historyFile) {
    throw new Error('Required file missing: data/history.json');
  }

  const historyJsonBytes = new Uint8Array(await historyFile.async('arraybuffer'));

  let historyJson: HistoryJson;
  try {
    historyJson = JSON.parse(new TextDecoder().decode(historyJsonBytes));
  } catch {
    throw new Error('data/history.json is not valid JSON');
  }

  // report_meta.json — optional
  let reportMeta: ReportMeta | null = null;
  const metaFile = zip.file('metadata/report_meta.json');
  if (metaFile) {
    try {
      const text = await metaFile.async('text');
      reportMeta = JSON.parse(text);
    } catch {
      // unparseable → checkers report this
    }
  }

  // Photos
  const photoFiles = new Map<string, Uint8Array>();
  const photoEntries = Object.entries(zip.files).filter(
    ([p, f]) => p.startsWith('photos/') && !f.dir
  );
  await Promise.all(
    photoEntries.map(async ([relativePath, file]) => {
      const name = relativePath.slice('photos/'.length);
      if (name) {
        const bytes = new Uint8Array(await file.async('arraybuffer'));
        photoFiles.set(name, bytes);
      }
    })
  );

  // seal.json — optional, present only in v2.0+ reports
  let sealJson: SealJson | null = null;
  const sealFile = zip.file('metadata/seal.json');
  if (sealFile) {
    try {
      const text = await sealFile.async('text');
      sealJson = JSON.parse(text) as SealJson;
    } catch {
      // unparseable seal — signatureVerification checker will handle this
    }
  }

  return { historyJson, reportMeta, sealJson, historyJsonBytes, photoFiles };
}
