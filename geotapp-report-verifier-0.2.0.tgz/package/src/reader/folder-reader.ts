import fs from 'node:fs/promises';
import path from 'node:path';
import type { ReportArtifact, HistoryJson, ReportMeta, SealJson } from '../types.js';

export async function readReportFromFolder(folderPath: string): Promise<ReportArtifact> {
  const historyPath = path.join(folderPath, 'data', 'history.json');
  const metaPath = path.join(folderPath, 'metadata', 'report_meta.json');

  // history.json is required
  let historyJsonBytes: Uint8Array;
  try {
    historyJsonBytes = new Uint8Array(await fs.readFile(historyPath));
  } catch {
    throw new Error(`Required file missing: data/history.json (looked in ${folderPath})`);
  }

  let historyJson: HistoryJson;
  try {
    historyJson = JSON.parse(new TextDecoder().decode(historyJsonBytes));
  } catch {
    throw new Error('data/history.json is not valid JSON');
  }

  // report_meta.json is optional (legacy reports may not have it)
  let reportMeta: ReportMeta | null = null;
  try {
    const metaBytes = await fs.readFile(metaPath, 'utf8');
    reportMeta = JSON.parse(metaBytes);
  } catch {
    // absent or unparseable → treat as legacy, errors reported by checkers
  }

  // seal.json — optional
  let sealJson: SealJson | null = null;
  try {
    const sealText = await fs.readFile(path.join(folderPath, 'metadata', 'seal.json'), 'utf8');
    sealJson = JSON.parse(sealText) as SealJson;
  } catch {
    // absent in legacy reports
  }

  // Load photo files if present
  const photoFiles = new Map<string, Uint8Array>();
  const photosDir = path.join(folderPath, 'photos');
  try {
    const entries = await fs.readdir(photosDir, { withFileTypes: true });
    for (const entry of entries) {
      if (!entry.isFile()) continue;
      const bytes = await fs.readFile(path.join(photosDir, entry.name));
      photoFiles.set(entry.name, new Uint8Array(bytes));
    }
  } catch {
    // photos dir absent → ok, checkers handle this
  }

  return { historyJson, reportMeta, sealJson, historyJsonBytes, photoFiles };
}
