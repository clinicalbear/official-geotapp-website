import { createHash } from 'node:crypto';

/**
 * Canonical JSON serializer for GeoTapp integrity hashes.
 *
 * MUST remain byte-for-byte compatible with:
 *   - geotapp-flow/lib/features/crm/services/project_history_export_service.dart → _canonicalizeForHash()
 *   - firebase-functions/src/index.ts → canonicalizeForHash() (when present)
 *
 * DO NOT modify without also updating both generators above.
 *
 * Rules:
 * - null/undefined → null
 * - booleans → unchanged
 * - strings → unchanged (UTF-8)
 * - integers → unchanged
 * - floats → Number.parseFloat(value.toFixed(12))  [matches Dart toStringAsFixed(12)]
 * - non-finite numbers → null
 * - -0 → 0  [explicit check via Object.is]
 * - arrays → preserve order, recurse
 * - objects → sort keys with plain .sort() (NOT localeCompare), recurse values
 * - Timestamps: already ISO-8601 strings in parsed JSON — no conversion needed
 */
export function canonicalizeForHash(value: unknown): unknown {
  if (value === null || value === undefined) return null;
  if (typeof value === 'boolean') return value;
  if (typeof value === 'string') return value;
  if (typeof value === 'number') {
    if (!Number.isFinite(value)) return null;
    if (Object.is(value, -0)) return 0;
    if (Number.isInteger(value)) return value;
    return Number.parseFloat(value.toFixed(12));
  }
  if (Array.isArray(value)) {
    return value.map(canonicalizeForHash);
  }
  if (typeof value === 'object') {
    const sorted = Object.keys(value as object).sort();
    const out: Record<string, unknown> = {};
    for (const k of sorted) {
      out[k] = canonicalizeForHash((value as Record<string, unknown>)[k]);
    }
    return out;
  }
  return String(value);
}

export function canonicalJson(value: unknown): string {
  return JSON.stringify(canonicalizeForHash(value));
}

export function sha256Hex(input: string): string {
  return createHash('sha256').update(input, 'utf8').digest('hex');
}

export function sha256HexBytes(bytes: Uint8Array): string {
  return createHash('sha256').update(bytes).digest('hex');
}
