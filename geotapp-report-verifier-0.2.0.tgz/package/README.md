# @geotapp/report-verifier

Offline integrity verifier for exported GeoTapp operational reports.

Answers: *"Is this GeoTapp report internally consistent and does it match the integrity metadata it claims to contain?"*

Works entirely offline from the report ZIP artifact — no API calls, no Firebase, no network required.

## Install

```bash
npm install @geotapp/report-verifier
```

## CLI

```bash
npx geotapp-report-verify path/to/report.zip
npx geotapp-report-verify path/to/report.zip --json
npx geotapp-report-verify path/to/extracted-folder/ --verbose
```

Exit codes: `0` = valid/degraded, `1` = invalid, `2` = I/O or parse error.

## Programmatic API

```typescript
import { verifyZipFile, verifyFolder, verifyArtifact } from '@geotapp/report-verifier';

const result = await verifyZipFile('./report.zip');
console.log(result.status);          // 'valid' | 'degraded' | 'invalid'
console.log(result.integrityLevel);  // 'full' | 'partial' | 'legacy' | 'invalid'
```

## Integrity Levels

| Level | Meaning |
|---|---|
| `full` | Archive seal present + all hashes valid + strong SHA-256 for all photos |
| `partial` | All hashes valid but archive seal absent or legacy photo fallbacks used |
| `legacy` | Report lacks modern integrity fields; structure is readable but not fully verifiable |
| `invalid` | Hash chain broken, root hash mismatch, or unrecoverable inconsistency |

## Verification Model

The verifier checks, in order:

1. **ZIP structure** — required files present
2. **history.json** — parseable, events array valid
3. **report_meta.json** — parseable, version fields present
4. **Event hash chain** — each event's SHA-256 matches its stored `eventHash`; `previousEventHash` links correctly
5. **Timeline hash** — recomputed from normalized event sequence matches stored `timelineHash`
6. **Photos bundle hash** — recomputed from photo metadata (with legacy fallback) matches stored `photosBundleHash`
7. **Report root hash** — SHA-256 of combined report payload matches stored `reportRootHash`
8. **Photo files** — physical bytes in ZIP match `fileSha256` in metadata (when present)
9. **Archive seal** — optional; if present, seal hashes must match report metadata

## Important

**`report.html` is informational only.** It is not part of the canonical verification inputs and is never hashed. The canonical verification inputs are `data/history.json` and `metadata/report_meta.json`.
